#!/bin/sh
set -e
mongoPath="/usr/local/mongodb"
etcPath="/etc/mongo"
systemDir="/usr/lib/systemd/system/"
logPath="/usr/local/mongodb/logs"
dataPath="/data/mongo/myset"
env_file="mongo.env"
version=`cat /etc/system-release | awk '{print $1}'`

port=$(cat $env_file |grep port |awk -F '=' '{print $2}')
sed -i "s/27017/$port/g" mongod.conf

if [[ ! -d "$mongoPath" ]]; then
 echo "$mongoPath not exist, download and install..."

 if [ $version == "Kylin" ]
 then
   wget https://rpmfind.net/linux/centos/8-stream/AppStream/x86_64/os/Packages/compat-openssl10-1.0.2o-3.el8.x86_64.rpm
   rpm -ivh compat-openssl10-1.0.2o-3.el8.x86_64.rpm
 fi


 curl -O https://fastdl.mongodb.org/linux/mongodb-linux-x86_64-rhel70-5.0.19.tgz
 tar -xzvf mongodb-linux-x86_64-rhel70-5.0.19.tgz
 mv mongodb-linux-x86_64-rhel70-5.0.19 $mongoPath
fi

if [[ ! -d "$etcPath" ]]; then
   echo "create $etcPath"
   mkdir -p $etcPath
   cp mongod.conf $etcPath
 else
   echo "$etcPath has exist"
   if [[ ! -f "$etcPath/mongo.keyfile" ]]; then
     echo "mongo.keyfile not exist in $etcPath"
     exit 1
   fi
   if [[ ! -f "$etcPath/mongod.conf" ]]; then
       echo "mv mongod.conf $etcPath"
       cp mongod.conf $etcPath
   fi
fi

rm -rf $dataPath $logPath
 
mkdir -p $dataPath $logPath

rm -rf /usr/lib/systemd/system/mongod.service
cp mongod.service /usr/lib/systemd/system/

echo "chown -R zdlz:zdlz $dataPath $mongoPath $etcPath"
chown -R zdlz:zdlz $dataPath $mongoPath $etcPath
 
echo 'start add mongo to PATH' 
# 将mongo 命令加到环境变量
echo 'export PATH=$PATH:/usr/local/mongodb/bin' >> /etc/profile


echo 'start mongo'
systemctl daemon-reload
systemctl start mongod
systemctl status mongod
echo 'start mongo success'
systemctl enable mongod


# 防火墙开启
status=`firewall-cmd --query-port=$port/tcp`
echo $status
if [ $status == "no" ]; then
   echo "firewall open $port"
    firewall-cmd --zone=public --add-port=$port/tcp --permanent
    firewall-cmd --reload
else
	echo "has opened"
fi
