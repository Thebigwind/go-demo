#!/bin/sh
set -e
etcPath="/etc/mongo"

if [[ ! -d "$etcPath" ]]; then
   echo "create $etcPath"
   mkdir -p $etcPath
fi

version=`cat /etc/system-release | awk '{print $1}'`
echo $version

if [ $version == "CentOS" ]
then
  echo "$version create mongo.keyfile"
  openssl rand -base64 90 -out ./mongo.keyfile
else
  echo "$version create mongo.keyfile"
  openssl rand -base64 90 > ./mongo.keyfile
fi

chmod 400 mongo.keyfile
mv mongo.keyfile $etcPath