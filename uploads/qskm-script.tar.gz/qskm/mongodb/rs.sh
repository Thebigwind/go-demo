#!/bin/sh

set -e


# 检查地址能否连通
check(){
	line=$1;
	machine=$(echo "$line"| /bin/cut -d':' -f1)|| exit 100
	port=$(echo "$line"| /bin/cut -d':' -f2)|| exit 101

	if  (echo >/dev/tcp/"$machine"/"$port") >/dev/null 2>&1; then
        echo "OK: $machine -> $port"
      else
        echo "ERROR: $machine -> $port"
        exit 102
      fi
}

env_file="mongo.env"
host1=$(cat $env_file|grep host1|awk -F '=' '{print $2}')
host2=$(cat $env_file|grep host2|awk -F '=' '{print $2}')
host3=$(cat $env_file|grep host3|awk -F '=' '{print $2}')
port=$(cat $env_file |grep port |awk -F '=' '{print $2}')
addr1="$host1:$port"
addr2="$host2:$port"
addr3="$host3:$port"
passwd=$(cat $env_file|grep password|awk -F '=' '{print $2}')
echo "$addr1,$addr2,$addr3"


# 检查端口是否联通
addrs=($addr1 $addr2 $addr3)
for addr in ${addrs[@]};do
	check $addr
done



/usr/local/mongodb/bin/mongo --eval 'rs.initiate({"_id":"myset","members":[{"_id":0,"priority":1, "host":"'$addr1'"},{"_id":1,"priority":2, "host":"'$addr2'"},{"_id":2, "priority":2, "host": "'$addr3'"}]})'
echo "create replicaSet success"
sleep 60
/usr/local/mongodb/bin/mongo admin  --eval 'db.createUser({user:"root",pwd:"'$passwd'",roles:[{role:"root", db:"admin"}]})'
echo "create root user success"
sleep 30
/usr/local/mongodb/bin/mongo mongodb://$addr1,$addr2,$addr3/qskm?replicaSet=myset -uroot --authenticationDatabase admin -p $passwd --eval \
        'db = db.getSiblingDB("qskm");db.createCollection("codebook");db.codebook.createIndex({"metadata.id":1});'

echo "create db success"





