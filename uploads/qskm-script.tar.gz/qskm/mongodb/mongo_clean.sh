#!/bin/bash

mongoPath="/usr/local/mongodb"
etcPath="/etc/mongo"
logPath="/usr/local/mongodb/logs"
dataPath="/data/mongo/myset"

systemctl stop mongod
rm -rf $mongoPath
rm -rf $logPath
rm -rf $dataPath
rm -f $etcPath/mongod.conf