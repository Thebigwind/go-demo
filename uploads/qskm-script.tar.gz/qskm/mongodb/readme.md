##mongo 高可用三节点部署

### 1. 在其中一个节点上执行 genkeyfile.sh, 生成mongo.keyfile，该文件会放在/etc/mongo 目录下。将/etc/mongo/mongo.keyfile文件copy到其他2节点/etc/mongo/目录下并更改文件权限 `chmod 400 /etc/mongo/mongo.keyfile`
### 2. 更改mongo.env 文件，更改节点ip,端口，配置密码，注意不要加双引号。host1为primary节点
### 3.在三个节点上执行sudo ./deploy.sh，部署启动mongo 服务。执行 `sudo systemctl status mongod` 可查看服务是否部署成功。
### 4. 在其中一个节点执行执行 `./rs.sh`  以设置集群, 创建root用户，创建qskm数据库，创建codebook表，建立索引。 