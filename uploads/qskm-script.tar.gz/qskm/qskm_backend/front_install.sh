#!/bin/bash
#前端
tar -vxzf /data/qskm/deploy/dist.tar.gz -C /data/qskm/deploy
mkdir -p /opt/qskm
\cp -r /data/qskm/deploy/static /opt/qskm
\cp -r /data/qskm/deploy/deploy/dist/* /usr/share/nginx/html