#!/bin/sh
set -e
mkdir -p /data/qskm
mkdir -p /amd64

#tar -vxf qskm.tar -C /data/qskm
\cp /data/qskm/deploy/third_party/libs/amd64/* /amd64

#
mkdir -p /usr/bin/configs
\cp /data/qskm/deploy/default.yml /usr/bin/configs/
\cp /data/qskm/deploy/rbac_model.conf /usr/bin/configs/
\cp -r /data/qskm/deploy/certfile /usr/bin/
\cp /data/qskm/deploy/qskm-backend /usr/local/bin
\cp /data/qskm/deploy/qskm-backend /usr/bin
\cp /data/qskm/deploy/license-manager /usr/local/bin
\cp /data/qskm/deploy/license-manager /usr/
\cp /data/qskm/deploy/liblicensepp.so.1.0.6 /amd64
\cp /data/qskm/deploy/liblicensepp.so.1.0.6 /usr/local/lib/
#systemd配置
if [[ ! -f "/usr/lib/systemd/system/qskm.service" ]]; then
  echo "copy qskm.service"
   cp qskm.service /usr/lib/systemd/system/
   systemctl daemon-reload
fi

echo 'start qskm'

systemctl start qskm
systemctl enable qskm
systemctl status qskm
echo 'start qskm success'

