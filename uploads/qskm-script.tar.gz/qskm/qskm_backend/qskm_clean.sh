#!/bin/bash

systemctl stop qskm
rm -f /usr/bin/qskm-backend
rm -f /usr/lib/systemd/system/qskm.service