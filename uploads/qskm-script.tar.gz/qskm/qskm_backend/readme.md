## 需要把qskm.tar的软件包，拷贝到 当前qskm_backend目录下，
## backend_install.sh脚本会从该目录解压qskm.tar到/data/qskm目录进行配置和安装
