#!/bin/sh
set -e

mkdir -p /amd64
cp ./third_party/libs/amd64/* /amd64

mkdir -p /usr/bin/configs
cp default.yml /usr/bin/configs/
cp rbac_model.conf /usr/bin/configs/
cp -r certfile /usr/bin/

rm -rf /usr/local/bin/qskm-backend
cp qskm-backend /usr/local/bin

   if [[ ! -f "/usr/lib/systemd/system/qskm.service" ]]; then
     echo "copy qskm.service"
     cp qskm.service /usr/lib/systemd/system/
     systemctl daemon-reload
   fi

echo 'start qskm'

systemctl start qskm
systemctl enable qskm
systemctl status qskm
echo 'start qskm success'