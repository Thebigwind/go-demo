export LD_LIBRARY_PATH=/amd64
nohup /usr/bin/qskm-backend --config /usr/bin/configs/default.yml serve  &