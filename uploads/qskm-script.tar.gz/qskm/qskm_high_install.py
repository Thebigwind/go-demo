# import pyyaml module
import os
import sys
import socket
import pwd
import yaml
from yaml.loader import SafeLoader

#根据总的yaml配置文件，写各自的配置文件，方便shell解析
def remove_env_file(file_path):
    try:
        os.remove(file_path)
        print("File removed successfully")
    except FileNotFoundError:
        print("File not found")
    except Exception as e:
        print(e)

def get_ip_address():
    # 创建UDP套接字
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # 连接到外部IP地址
        s.connect(('8.8.8.8', 80))
        # 获取本机IP地址
        ip_address = s.getsockname()[0]
    except Exception as e:
        print(e)
        ip_address = None
    finally:
        s.close()
    return ip_address


# 读取 YAML 文件
def read_yaml_file(file_path):
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
    return data


# 修改 YAML 文件中的数据
def modify_yaml_file(file_path, key_path, new_value):
    data = read_yaml_file(file_path)
    current_node = data

    # 根据 key_path 寻找目标节点
    for key in key_path[:-1]:
        if key in current_node:
            current_node = current_node[key]
        else:
            print(f"Key '{key}' not found in the YAML file.")
            return

    # 修改目标节点的值
    key = key_path[-1]
    current_node[key] = new_value

    # 将修改后的数据写回 YAML 文件
    with open(file_path, 'w') as file:
        yaml.dump(data, file)


def get_host_list():
    #
    host_list = []
    with open('qskm.yml') as f:
        data = list(yaml.load_all(f, Loader=SafeLoader))
        for dic in data:
            #print(dic)
            for key in dic:
                if key == "Mysql":
                 subData = dic[key]
                 for k in subData:
                    if k == "MasterHost":
                        host_list.append(subData[k])
                    elif k == "Slave1Host":
                        host_list.append(subData[k])
                    elif k == "Slave2Host":
                        host_list.append(subData[k])
    return host_list


def scp_to_other_host(src_file_path):
   host_list = get_host_list()
   for host in host_list:
       if host == get_ip_address():
           continue
       target_file_path = src_file_path
       command = "scp " + src_file_path + " " +  host + ":" + target_file_path
       print(command)
       os.system(command)


def get_mysql_info():
    with open('qskm.yml') as f:
        data = list(yaml.load_all(f, Loader=SafeLoader))
        for dic in data:
            for key in dic:
                if key == "Mysql":
                 subData = dic[key]
    return subData

def get_redis_info():
    with open('qskm.yml') as f:
        data = list(yaml.load_all(f, Loader=SafeLoader))
        for dic in data:
            for key in dic:
                if key == "Redis":
                 subData = dic[key]
    return subData

def get_mongo_info():
    with open('qskm.yml') as f:
        data = list(yaml.load_all(f, Loader=SafeLoader))
        for dic in data:
            for key in dic:
                if key == "Mongo":
                 subData = dic[key]
    return subData

def get_nginx_info():
    with open('qskm.yml') as f:
        data = list(yaml.load_all(f, Loader=SafeLoader))
        for dic in data:
            for key in dic:
                if key == "Nginx":
                 subData = dic[key]
    return subData

def get_keepalived_info():
    with open('qskm.yml') as f:
        data = list(yaml.load_all(f, Loader=SafeLoader))
        for dic in data:
            for key in dic:
                if key == "Keepalived":
                 subData = dic[key]
    return subData

def config_mysql_env():
    print("开始配置mysql env")
    mysql_info_dict = get_mysql_info()
    mysql_env_file = os.path.join(os.getcwd(), "mysql/mysql.env")
    remove_env_file(mysql_env_file)

    for k in mysql_info_dict:
        content = k + "=" + mysql_info_dict[k]
        with open(mysql_env_file,mode='a',encoding='utf-8') as f:
             f.write(content)
             f.write("\n")
    #拷贝文件到其它机器
    scp_to_other_host(mysql_env_file)

def config_mongo_env():
    print("开始配置mongo env")
    mongo_info_dict = get_mongo_info()
    mongo_env_file = os.path.join(os.getcwd(), "mongodb/mongo.env")
    remove_env_file(mongo_env_file)

    for k in mongo_info_dict:
        content = k + "=" + mongo_info_dict[k]
        with open(mongo_env_file, mode='a',encoding='utf-8') as f:
             f.write(content)
             f.write("\n")
    #拷贝文件到其它机器
    scp_to_other_host(mongo_env_file)

def config_redis_env():
    print("开始配置redis env")
    redis_info_dict = get_redis_info()
    redis_env_file = os.path.join(os.getcwd(), "redis/redis-config.sh")
    remove_env_file(redis_env_file)

    for k in redis_info_dict:

        if k == "redis_backup_ips":
            content = k + '="' + redis_info_dict[k] + '"'
        else:

            content = k + "=" + redis_info_dict[k]
        with open(redis_env_file, mode='a',encoding='utf-8') as f:
             f.write(content)
             f.write("\n")
    #拷贝文件到其它机器
    scp_to_other_host(redis_env_file)

def config_nginx_env():
    print("开始配置nginx env")
    nginx_info_dict = get_nginx_info()
    nginx_env_file = os.path.join(os.getcwd(), "nginx/nginx-config.sh")
    remove_env_file(nginx_env_file)

    for k in nginx_info_dict:

        if k == "nginx_backup_ips":
            #content = '"' + content + '"'
            content = k + '="' + nginx_info_dict[k] + '"'
        else:
            content = k + "=" + nginx_info_dict[k]

        with open(nginx_env_file, mode='a',encoding='utf-8') as f:
             f.write(content)
             f.write("\n")
    #拷贝文件到其它机器
    scp_to_other_host(nginx_env_file)

def config_keepalived_env():
    print("开始配置keeplived env")
    keepalived_info_dict = get_keepalived_info()
    keepalived_env_file = os.path.join(os.getcwd(), "keepalived/keepalived-config.sh")
    remove_env_file(keepalived_env_file)

    for k in keepalived_info_dict:
        content = k + "=" + keepalived_info_dict[k]
        with open(keepalived_env_file, mode='a',encoding='utf-8') as f:
             f.write(content)
             f.write("\n")
    #拷贝文件到其它机器
    scp_to_other_host(keepalived_env_file)


def config_qskm_default_yaml():
    print("开始配置qskm default.yml")
    #
    file_path = "/data/qskm/deploy/default.yml"
    #修改mysql信息
    mysql_info = get_mysql_info()
    #改host
    key_path = ["mysql", "host"]
    new_value = mysql_info["VirtualIp"]
    modify_yaml_file(file_path, key_path, new_value)
    #改端口号
    key_path = ["mysql", "port"]
    new_value = mysql_info["MysqlPort"]
    modify_yaml_file(file_path, key_path, new_value)

    #修改mongo信息
    #修改连接地址
    mongo_info = get_mongo_info()
    key_path = ["mongodb", "addrs"]
    new_value = []
    new_value.append(mongo_info["host1"] + ":" + mongo_info["port"])
    new_value.append(mongo_info["host2"] + ":" + mongo_info["port"])
    new_value.append(mongo_info["host3"] + ":" + mongo_info["port"])
    modify_yaml_file(file_path, key_path, new_value)

    #修改redis信息
    #改端口号
    redis_info = get_redis_info()
    key_path = ["redis", "port"]
    new_value = redis_info["redis_port"]
    modify_yaml_file(file_path, key_path, new_value)
    #修改redis host
    key_path = ["redis", "host"]
    new_value = redis_info["redis_vip"]
    modify_yaml_file(file_path, key_path, new_value)
    #修改redis host
    key_path = ["redis", "password"]
    new_value = redis_info["redis_passwd"]
    modify_yaml_file(file_path, key_path, new_value)

    #改配置文件路径
    key_path = ["casbin", "model_dir"]
    new_value = "/usr/bin/configs/rbac_model.conf"
    modify_yaml_file(file_path, key_path, new_value)

    key_path = ["certmanage", "root_path"]
    new_value = "/usr/bin/certfile/root"
    modify_yaml_file(file_path, key_path, new_value)

    #deploy部署
#     key_path = ["deploy", "mode"]
#     new_value = "cluster"
#     modify_yaml_file(file_path, key_path, new_value)
#
#     key_path = ["deploy", "ip"]
#     ips = []
#     ips.append(mongo_info["host1"])
#     ips.append(mongo_info["host2"])
#     ips.append(mongo_info["host3"])
#     new_value = ips
#     modify_yaml_file(file_path, key_path, new_value)

    #拷贝文件到其它机器
    scp_to_other_host(file_path)



# 1. 当前的mono的 sh mongodb/genkeyfile.sh
# 2. 然后拷贝生成的文件到其它机器；
# 3. 当前机器的mongo1; sh mongodb/deploy.sh
# 4. 其它机器的mongo2; ssh 10.10.10.xx sh  /xxxx/mongodb/deploy.sh
# 5. 其它机器的mongo3; ssh 10.10.10.xx sh  /xxxx/mongodb/deploy.sh
#
# 6. mysql master;
# 7. mysql slave1;
# 8. mysql salve2;
#
# 9. redis master;
# 10. redis slave1;
# 11. redis slave2;
#
# 12.nginx master
# 13.nginx slave1;
# 14.nginx slave2;
#
# 15.qskm  当前机器;
# 16.qskm  其它机器1;
# 17.qskm  其它机器2;


def install_mongo():
    print("按mongo安装依赖顺序安装各组件")
    #1. 当前机器mongo
    script_path = os.path.join(os.getcwd(),"mongodb/genkeyfile.sh")
    command = "sh " + script_path
    os.system(command)
    os.system("mkdir -p /etc/mongo")
    keyfile = os.path.join(os.getcwd(),"mongodb/mongo.keyfile")
    command = "\cp " + keyfile + "  /etc/mongo"
    os.system(command)

    #其它机器
    host_list = get_host_list()
    for host in host_list:
        if host == get_ip_address():
            continue
        #创建目录
        command = "ssh %s mkdir -p /etc/mongo" % (host)
        print("command: %s" % command)
        os.system(command)
        #拷贝keyfile
        src_file_path = "/etc/mongo/mongo.keyfile"
        target_file_path = src_file_path
        command = "scp %s %s:%s" %(src_file_path, host, target_file_path )
        print(command)
        os.system(command)
    #安装
    for host in host_list:
        script_path = os.path.join(os.getcwd(), "mongodb/deploy.sh")
        script_dir = os.path.join(os.getcwd(), "mongodb")
        #command = "ssh %s sh %s" % (host, script_path)
        command = "ssh %s sh -c 'pwd && cd %s && sh %s '" % (host, script_dir, script_path)
        os.system(command)

def install_mysql():
    print("按mysql安装依赖顺序安装各组件")
    mysql_info = get_mysql_info()
    #先安装master
    print("安装master")
    mysql_master_host = mysql_info["MasterHost"]
    script_path = os.path.join(os.getcwd(), "mysql/mysql.sh")
    script_dir = os.path.join(os.getcwd(), "mysql")
    command = "ssh %s sh -c 'pwd && cd %s && sh %s '" % (mysql_master_host,script_dir, script_path)
    #print("安装master command:%s") % (command)
    print(command)
    os.system(command)

    #再安装slave1
    print("安装slave1")
    mysql_slave1_host = mysql_info["Slave1Host"]
    #script_path = os.path.join(os.getcwd(), "mysql/mysql.sh")
    #command = "ssh %s sh %s" % (mysql_slave1_host, script_path)
    command = "ssh %s sh -c 'pwd && cd %s && sh %s' " % (mysql_slave1_host, script_dir, script_path)
    #print("安装slave1 command:%s") % (command)
    print(command)
    os.system(command)

    #最后安装slave2,会和manager一起安装
    print("安装slave2 和 manager")
    mysql_slave2_host = mysql_info["Slave2Host"]
    #script_path = os.path.join(os.getcwd(), "mysql/mysql.sh")
    #command = "ssh %s sh %s" % (mysql_slave2_host, script_path)
    command = "ssh %s sh -c 'pwd && cd %s && sh %s '" % (mysql_slave2_host, script_dir, script_path)
    #print("安装slave1 command:%s") % (command)
    print(command)
    os.system(command)

def install_redis():
    print("按redis安装依赖顺序安装各组件")
    #先安装master
    redis_info = get_redis_info()
    redis_master_host = redis_info["redis_master_ip"]
    script_path = os.path.join(os.getcwd(), "redis/redis-install.sh")
    script_dir = os.path.join(os.getcwd(), "redis")
    #command = "ssh %s sh %s" % (redis_master_host, script_path)
    command = "ssh %s sh -c 'pwd && cd %s && sh %s' " % (redis_master_host, script_dir, script_path)
    #print("安装master command:%s") % (command)
    print(command)
    os.system(command)
    #再安装其它节点
    host_list = get_host_list()
    for host in host_list:
        if host == redis_master_host:
            continue
        #script_path = os.path.join(os.getcwd(), "redis/redis-install.sh")
        #command = "ssh %s sh %s" % (host, script_path)
        command ="ssh %s sh -c 'pwd && cd %s && sh %s' " % (host, script_dir, script_path)
        print(command)
        os.system(command)


def install_nginx():
    print("按nginx安装顺序安装各组件,无先后顺序要求")
    host_list = get_host_list()
    for host in host_list:
        script_path = os.path.join(os.getcwd(), "nginx/nginx-install.sh")
        script_dir = os.path.join(os.getcwd(), "nginx")
        #command = "ssh %s sh %s" % (host, script_path)
        command = "ssh %s sh -c 'pwd && cd %s && sh %s '" % (host, script_dir, script_path)
        print (command)
        os.system(command)


def install_qskm():
    print("安装顺序qskm,无先后顺序要求")
    #初始化mysql库表结构和数据
    #command = "ssh %s sh -c 'pwd && cd %s && sh %s '" % (host, script_dir, script_path)
    script_path = os.path.join(os.getcwd(), "mysql/init_mysql_table_data.sh")
    script_dir = os.path.join(os.getcwd(), "mysql")
    curr_host = get_ip_address()
    command = "ssh %s sh -c 'pwd && cd %s && sh %s '" % (curr_host, script_dir, script_path)
    print(command)
    os.system(command)
    print('--------------------------------')
    #os.system("cd mysql && sh init_mysql_table_data.sh")
    #初始化mongo库
    script_path = os.path.join(os.getcwd(), "mongodb/rs.sh")
    script_dir = os.path.join(os.getcwd(), "mongodb")
    command = "ssh %s sh -c 'pwd && cd %s && sh %s '" % (curr_host, script_dir, script_path)
    print(command)
    os.system(command)
    #os.system("sh mongodb/rs.sh")

    host_list = get_host_list()
    #安装qskm
    for host in host_list:
        #安装后端
        script_path = os.path.join(os.getcwd(), "qskm_backend/backend_install.sh")
        script_dir = os.path.join(os.getcwd(), "qskm_backend")
        #command = "ssh %s sh %s" % (host, script_path)
        command = "ssh %s sh -c 'pwd && cd %s && sh %s '" % (host, script_dir, script_path)
        print (command)
        os.system(command)
        #启动后端
        script_path = os.path.join(os.getcwd(), "qskm_backend/backend_start.sh")
        #command = "ssh %s sh %s" % (host, script_path)
        command = "ssh %s sh -c 'pwd && cd %s && sh %s '" % (host, script_dir, script_path)
        print(command)
        os.system(command)
        #安装前端
        script_path =  os.path.join(os.getcwd(), "qskm_backend/front_install.sh")
        #command = "ssh %s sh %s" % (host, script_path)
        command = "ssh %s sh -c 'pwd && cd %s && sh %s '" % (host, script_dir, script_path)
        print (command)
        os.system(command)

#


def config_script_env():
    config_mysql_env()
    config_mongo_env()
    config_redis_env()
    config_nginx_env()
    config_keepalived_env()
    config_qskm_default_yaml()


def install_in_order():
    install_mysql()
    install_mongo()
    install_redis()
    install_nginx()
    install_qskm()

def check_user2(user):
    usernames = [x[0] for x in pwd.getpwall()]
    if user in usernames:
        print(user + "已存在")
    else:
        #os.system("useradd -m -p "+upass+" "+uname)
        print("开始添加用户"+user)
        os.system("useradd " + user)

def check_user():
    host_list = get_host_list()
    for host in host_list:
        script_path = os.path.join(os.getcwd(), "check_user.sh")
        script_dir = os.path.join(os.getcwd())
        command = "ssh %s sh -c 'pwd && cd %s && sh %s '" % (host, script_dir, script_path)
        print(command)
        os.system(command)

def main(args):
    check_user()

    print("开始解析qskm.yml,生成各组件的配置.")
    config_script_env()
    print("生成各组件配置完成")

    if len(args) > 1:
        arg = args[1]
        if arg == "mysql":
            config_mysql_env()
            install_mysql()
        elif arg == "mongo":
            config_mongo_env()
            install_mongo()
        elif arg == "redis":
            config_redis_env()
            config_keepalived_env()
            install_redis()
        elif arg == "nginx":
            config_nginx_env()
            config_keepalived_env()
            install_nginx()
        elif arg == "qskm":
            config_qskm_default_yaml()
            install_qskm()
    else:
        print("开始解析qskm.yml,生成各组件的配置.")
        config_script_env()
        print("开始调度安装各组件：")
        install_in_order()

if __name__ == "__main__":
    main(sys.argv)



