import os
import sys
import socket
import yaml
from yaml.loader import SafeLoader

def get_host_list():
    #
    host_list = []
    with open('qskm.yml') as f:
        data = list(yaml.load_all(f, Loader=SafeLoader))
        for dic in data:
            #print(dic)
            for key in dic:
                if key == "Mysql":
                 subData = dic[key]
                 for k in subData:
                    if k == "MasterHost":
                        host_list.append(subData[k])
                    elif k == "Slave1Host":
                        host_list.append(subData[k])
                    elif k == "Slave2Host":
                        host_list.append(subData[k])
    print(host_list)
    return host_list

def high_clean_all():
    host_list = get_host_list()
    for host in host_list:
         print("开始清理mysql...")
         mysql_clean = os.path.join(os.getcwd(), "mysql/mysql_clean.sh")
         command = "ssh %s sh %s" % (host, mysql_clean)
         os.system(command)

         print("开始清理mongo...")
         mongo_clean = os.path.join(os.getcwd(), "mongodb/mongo_clean.sh")
         command = "ssh %s sh %s" % (host, mongo_clean)
         os.system(command)

         print("开始清理redis...")
         redis_clean = os.path.join(os.getcwd(), "redis/redis-clean.sh")
         command = "ssh %s sh %s" % (host, redis_clean)
         os.system(command)

         print("开始清理nginx...")
         nginx_clean = os.path.join(os.getcwd(), "nginx/nginx-clean.sh")
         command = "ssh %s sh %s" % (host, nginx_clean)
         os.system(command)

         print("开始清理qskm...")
         qskm_clean = os.path.join(os.getcwd(), "qskm_backend/qskm_clean.sh")
         command = "ssh %s sh %s" % (host, qskm_clean)
         os.system(command)

def high_clean_mysql():
    host_list = get_host_list()
    for host in host_list:
         print("开始清理mysql...")
         mysql_clean = os.path.join(os.getcwd(), "mysql/mysql_clean.sh")
         command = "ssh %s sh %s" % (host, mysql_clean)
         os.system(command)

def high_clean_mongo():
    host_list = get_host_list()
    for host in host_list:
         print("开始清理mongo...")
         mongo_clean = os.path.join(os.getcwd(), "mongodb/mongo_clean.sh")
         command = "ssh %s sh %s" % (host, mongo_clean)
         os.system(command)

def high_clean_redis():
    host_list = get_host_list()
    for host in host_list:
         print("开始清理redis...")
         redis_clean = os.path.join(os.getcwd(), "redis/redis-clean.sh")
         command = "ssh %s sh %s" % (host, redis_clean)
         os.system(command)

def high_clean_nginx():
    host_list = get_host_list()
    for host in host_list:
         print("开始清理nginx...")
         nginx_clean = os.path.join(os.getcwd(), "nginx/nginx-clean.sh")
         command = "ssh %s sh %s" % (host, nginx_clean)
         os.system(command)

def main(args):
    if len(args) > 1:
        arg = args[1]
        if arg == "mysql":
            high_clean_mysql()
        elif arg == "mongo":
            high_clean_mongo()
        elif arg == "redis":
            high_clean_redis()
        elif arg == "nginx":
            high_clean_nginx()
    else:
        high_clean_all()


if __name__=="__main__":
    print("start..")
    main(sys.argv)
