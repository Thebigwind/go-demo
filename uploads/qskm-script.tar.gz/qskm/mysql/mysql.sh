#!/bin/bash

SHELL_SCRIPT_PATH=$(cd $(dirname $0); pwd)
echo "SHELL_SCRIPT_PATH:"$SHELL_SCRIPT_PATH
#读取的变量
Mysql_Env_File=${SHELL_SCRIPT_PATH}/mysql.env
#cat mysql.env|grep MasterHost|awk -F '=' '{print $2}'
MYSQL_PASS=$(cat $Mysql_Env_File|grep MysqlPass|awk -F '=' '{print $2}')
MYSQL_PORT=$(cat $Mysql_Env_File|grep MysqlPort|awk -F '=' '{print $2}')
MASTER_HOST=$(cat $Mysql_Env_File|grep MasterHost|awk -F '=' '{print $2}')
SLAVE1_HOST=$(cat $Mysql_Env_File|grep Slave1Host|awk -F '=' '{print $2}')
SLAVE2_HOST=$(cat $Mysql_Env_File|grep Slave2Host|awk -F '=' '{print $2}')
MANAGER_HOST=$(cat $Mysql_Env_File|grep ManagerHost|awk -F '=' '{print $2}')
VIR_IP=$(cat $Mysql_Env_File|grep VirtualIp|awk -F '=' '{print $2}')

cur_ip=$(hostname -I|awk -F" " '{print $1}')
DEV=$(ip a|grep ${cur_ip}|awk -F " " '{print $8}')
echo "dev:"$DEV

MYSQL_DIR=$(cat $Mysql_Env_File|grep MYSQL_DIR|awk -F '=' '{print $2}')
BASE_DIR=$(cat $Mysql_Env_File|grep BASE_DIR|awk -F '=' '{print $2}')
DATA_DIR=$(cat $Mysql_Env_File|grep DATA_DIR|awk -F '=' '{print $2}')
LOG_DIR=$(cat $Mysql_Env_File|grep LOG_DIR|awk -F '=' '{print $2}')


mkdir -p $MYSQL_DIR
mkdir -p $DATA_DIR
mkdir -p $LOG_DIR
result(){
  if [ $? -eq 0 ]; then
    echo "$1成功。"
  else
    echo "$1失败"
    exit 1
  fi
}

#发送邮件，manager所在节点
install_send_email(){

  echo "current pwd:"${PWD}
  yum install sendEmail -y
  mkdir -p ${MYSQL_DIR}/masterha/
  sed -i "3c MYSQL_DIR=${MYSQL_DIR}" ${SHELL_SCRIPT_PATH}/manager_report_script.sh
  sed -i "3c MYSQL_DIR=${MYSQL_DIR}" ${SHELL_SCRIPT_PATH}/send_email.sh

  \cp ${SHELL_SCRIPT_PATH}/manager_report_script.sh  ${MYSQL_DIR}/masterha/manager_report_script
  \cp ${SHELL_SCRIPT_PATH}/send_email.sh ${MYSQL_DIR}/masterha/send_email
  chmod 755 ${MYSQL_DIR}/masterha/manager_report_script
  chmod 755 ${MYSQL_DIR}/masterha/send_email
}

#设置虚拟ip
set_vir_ip(){
  cur_ip=$(hostname -I|awk -F" " '{print $1}')
  echo "cur_ip:"${cur_ip}
  nic=$(ip a|grep ${cur_ip}|awk -F " " '{print $8}')
  echo "nic:"${nic}
  #设置虚拟ip
  ifconfig ${nic}:1 ${VIR_IP}
}

#检查防火墙
open_firewall_port(){
  echo "检查防火墙是否开启"
  systemctl status firewalld
  if [ $? = 0 ];then
      echo 'firewall open '$1
      port_status=$(firewall-cmd --query-port=$1/tcp)
      if [ $port_status = 'no' ]; then
          firewall-cmd --zone=public --add-port=$1/tcp --permanent
          firewall-cmd --reload
      fi
  fi
}

#安装数据库
MYSQL_INSTALL(){
  #检查是否已安装mysql
  if [ -d "${BASE_DIR}" ]; then
    echo "${BASE_DIR} already exist,please remove first: rm -rf ${BASE_DIR}; rm -rf ${DATA_DIR}; rm /etc/my.cnf; rm /etc/rc.d/init.d/mysqld"
    exit 1;
  fi

  #下载包
  package=mysql-8.0.24-linux-glibc2.12-x86_64.tar.xz
  #${MYSQL_DIR}/

  if [ -e $package ] ; then
    echo "Found $package"
  else
    echo "开始下载..."
    wget https://downloads.mysql.com/archives/get/p/23/file/$package
    result "下载包"
  fi

  #解压
  echo "开始解压..."
  tar -xvf $package -C ${MYSQL_DIR}
  result "解压包"
  #重命名
  mv ${MYSQL_DIR}/mysql-8.0.24-linux-glibc2.12-x86_64 ${MYSQL_DIR}/mysql-8.0.24


  #创建数据目录
  echo "开始创建数据目录"
  mkdir -p "${DATA_DIR}"
  mkdir -p "${LOG_DIR}"
  echo "" > ${LOG_DIR}/mysqld.log

  echo "开始设置my_default.cnf..."
  #在 $datadir/support-files目录下创建my_default.cnf
  touch ${BASE_DIR}/support-files/my_default.cnf
  cat>${BASE_DIR}/support-files/my_default.cnf<<EOF
[mysqld]
port=${MYSQL_PORT}
basedir=${BASE_DIR}
datadir=${DATA_DIR}
socket=${DATA_DIR}/mysql.sock

character-set-server=utf8
collation-server=utf8_general_ci
#performance_schema_max_table_instances=400
#table_definition_cache=400
#table_open_cache=256
#datadir=/var/lib/mysql
#socket=/var/lib/mysql/mysql.sock
# Disabling symbolic-links is recommended to prevent assorted security risks
#symbolic-links=0
# Settings user and group are ignored when systemd is used.
# If you need to run mysqld under a different user or group,
# customize your systemd unit file for mariadb according to the
# instructions in http://fedoraproject.org/wiki/Systemd
max_allowed_packet=1024M
max_connections=1000
# Recommended in standard MySQL setup
sql_mode=NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION
wait_timeout=2147483
interactive_timeout=2147483
connect_timeout=20
thread_cache_size=256
lower_case_table_names=1
innodb_strict_mode=0
# 创建新表时将使用的默认存储引擎
default-storage-engine=INNODB
default_authentication_plugin=mysql_native_password
innodb_file_per_table=1
log_bin_trust_function_creators=1







[mysqld_safe]
log-error=${DATA_DIR}/mysqld.log
pid-file=${DATA_DIR}/mysqld.pid
default-character-set=utf8
[mysql]
default-character-set=utf8
[mysql.server]
default-character-set=utf8
[client]
#default-character-set=utf8
socket=${DATA_DIR}/mysql.sock
#
# include all files from the config directory
#
#!includedir /etc/my.cnf.d

EOF

  result "配置my_default.cnf"

  #拷贝配置文件
  \cp ${BASE_DIR}/support-files/my_default.cnf /etc/my.cnf
  result "拷贝my_default.cnf -> /etc/my.cnf"
  #初始化Mysql,并获取登录密码
  ${BASE_DIR}/bin/mysqld --initialize --user=zdlz --basedir=${BASE_DIR} --datadir=${DATA_DIR}
  result "初始化mysql"
  #echo "临时密码是:"$pwd

  #获取临时密码
  #pwd=$(grep 'temporary password' $datadir/mysqld.log | awk -F "root@localhost:" '{print $2}')
  #echo "临时密码是:"$pwd
  echo "请输入屏幕上显示的临时密码:"
  TEMP_PASSWORD=$(bash -c 'read  -p  "temp Password:" pass; echo $pass')


  echo "开始把启动脚本放到开机初始化目录"
  \cp ${BASE_DIR}/support-files/mysql.server /etc/rc.d/init.d/mysqld

  #46:basedir,47:datadir
  sed -i "46c basedir=${BASE_DIR}" /etc/rc.d/init.d/mysqld
  sed -i "47c datadir=${DATA_DIR}" /etc/rc.d/init.d/mysqld
  chmod +x /etc/rc.d/init.d/mysqld

  #开机启动
  chkconfig --add mysqld

  #配置
  sed -i '266c $bindir/mysqld_safe --user=root  --datadir="$datadir" --pid-file="$mysqld_pid_file_path" $other_args >/dev/null &' /etc/rc.d/init.d/mysqld

  #启动mysql
  service mysql start
  result "启动mysql"

  echo "mysql客户端加入/usr/bin"
  ln -s ${BASE_DIR}/bin/mysql /usr/bin
  ln -s ${BASE_DIR}/bin/mysqlbinlog /usr/bin

  #建数据库用户和修改数据库连接
  #通过临时密码登录MySQ
 # EXEC_SQL="ALTER USER 'root'@'localhost' IDENTIFIED BY '${MYSQL_PASS}'; FLUSH PRIVILEGES; use mysql;update user set host='%' where user='root'; FLUSH PRIVILEGES; grant all privileges on *.* to 'root'@'%';FLUSH PRIVILEGES;"

mysql -uroot  -p${TEMP_PASSWORD} -P ${MYSQL_PORT}  --connect-expired-password  <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED BY '${MYSQL_PASS}'; FLUSH PRIVILEGES; use mysql;update user set host='%' where user='root'; FLUSH PRIVILEGES; grant all privileges on *.* to 'root'@'%';FLUSH PRIVILEGES;
EOF
  result "修改mysql密码"

  echo "安装mysql已完成"
  echo "mysql_master_slave_config">schedule.log
}

MYSQL_MASTER_SLAVE_CONFIG(){
  #读取环境变量

  current_ip=$(hostname -I|awk -F" " '{print $1}')
  echo "current_node:"${current_ip}
  echo "current_ip:"${current_ip}
  serverid=$(echo $current_ip|awk -F"." '{print $4}')
  echo "serverid:"${serverid}

  if [ ${current_ip} = ${MASTER_HOST} ]; then
    echo "config master..."
    sed -i "36c server-id=${serverid}"  /etc/my.cnf  ##server-id与从服务器server-id不能重复
    sed -i '37c log-bin=master-bin' /etc/my.cnf #添加，主服务器开启二进制文件
    sed -i '38c log_slave-updates=true' /etc/my.cnf #添加，允许从服务器更新二进制文件
  else
    echo "config slave..."
    sed -i "36c server-id=${serverid}"  /etc/my.cnf  ##server-id与从服务器server-id不能重复
    sed -i '37c log-bin=master-bin' /etc/my.cnf #添加，主服务器开启二进制文件
    sed -i '38c relay-log=relay-log-bin' /etc/my.cnf
    sed -i '39c relay-log-index=slave-relay-bin.index' /etc/my.cnf
    sed -i '40c relay_log_purge=0' /etc/my.cnf
    sed -i '41c read_only=1' /etc/my.cnf
  fi
  result "配置/etc/my.cnf"

  #重启服务
  systemctl restart mysqld
  systemctl restart mysql
  result "重启mysql服务"


  echo "建myslave,mha用户及授权"
  MY_SLAVE_SQL="CREATE USER 'myslave'@'%' IDENTIFIED BY '123456'; FLUSH PRIVILEGES; use mysql;update user set host='%' where user='myslave'; FLUSH PRIVILEGES; grant all privileges on *.* to 'myslave'@'%';FLUSH PRIVILEGES;"
mysql -uroot  -p${MYSQL_PASS} -P ${MYSQL_PORT}  --connect-expired-password  <<EOF
CREATE USER 'myslave'@'%' IDENTIFIED BY '123456'; FLUSH PRIVILEGES; use mysql;update user set host='%' where user='myslave'; FLUSH PRIVILEGES; grant all privileges on *.* to 'myslave'@'%';FLUSH PRIVILEGES;
EOF
result "创建myslave用户及授权"


  MHA_SQL="CREATE USER 'mha'@'%' IDENTIFIED BY '123456'; FLUSH PRIVILEGES; use mysql;update user set host='%' where user='mha'; FLUSH PRIVILEGES; grant all privileges on *.* to 'mha'@'%';FLUSH PRIVILEGES;"
mysql -uroot  -p${MYSQL_PASS} -P ${MYSQL_PORT}  --connect-expired-password  <<EOF
CREATE USER 'mha'@'%' IDENTIFIED BY '123456'; FLUSH PRIVILEGES; use mysql;update user set host='%' where user='mha'; FLUSH PRIVILEGES; grant all privileges on *.* to 'mha'@'%';FLUSH PRIVILEGES;
EOF
result "创建mha用户及授权"

  echo "安装master半同步插件"
  SYNC_MASTER_SQL="INSTALL PLUGIN rpl_semi_sync_master SONAME 'semisync_master.so'"
  echo "mysql -uroot -p"${MYSQL_PASS}" -P ${MYSQL_PORT} --connect-expired-password -e  \"${SYNC_MASTER_SQL}\""
  mysql -uroot  -p${MYSQL_PASS} -P ${MYSQL_PORT}  --connect-expired-password  <<EOF
INSTALL PLUGIN rpl_semi_sync_master SONAME 'semisync_master.so'
EOF
result "安装master半同步插件"


  echo "安装slave半同步插件"
  SYNC_SLAVE_SQL="INSTALL PLUGIN rpl_semi_sync_slave SONAME 'semisync_slave.so'"
  echo "mysql -uroot -p"${MYSQL_PASS}" -P ${MYSQL_PORT} --connect-expired-password -e  \"${SYNC_SLAVE_SQL}\""
  mysql -uroot  -p${MYSQL_PASS} -P ${MYSQL_PORT}  --connect-expired-password  <<EOF
INSTALL PLUGIN rpl_semi_sync_slave SONAME 'semisync_slave.so'
EOF
result "安装slave半同步插件"

  #激活半同步
  ACTIVE_SYNC_SQL="set global rpl_semi_sync_master_enabled=on;"
  #echo "mysql -uroot -p"${MYSQL_PASS}" -P ${MYSQL_PORT}  --connect-expired-password -e  \"${ACTIVE_SYNC_SQL}\""
   mysql -uroot  -p${MYSQL_PASS} -P ${MYSQL_PORT}  --connect-expired-password  <<EOF
set global rpl_semi_sync_master_enabled=on;
EOF
result "激活master半同步插件"

  #ACTIVE_SYNC_SQL="set global rpl_semi_sync_slave_enabled=on;"
  #mysql -uroot -p"${MYSQL_PASS}" -P ${MYSQL_PORT}  --connect-expired-password -e \"${ACTIVE_SYNC_SQL}\" &> /dev/null
  mysql -uroot  -p${MYSQL_PASS} -P ${MYSQL_PORT}  --connect-expired-password  <<EOF
set global rpl_semi_sync_slave_enabled=on;
EOF
result "激活slave半同步插件"

  if [ ${current_ip} != ${MASTER_HOST} ]; then
    echo "开始配置从库。。"
    #配置主从


    echo "mysql -uroot -p"${MYSQL_PASS}" -h "${MASTER_HOST}"  -P ${MYSQL_PORT}  --connect-expired-password   -e 'show master status' | awk -F' ' 'NR>1 {print \$1","\$2}'"
    master_status=$(mysql -uroot -p"${MYSQL_PASS}" -h "${MASTER_HOST}"  -P ${MYSQL_PORT}   --connect-expired-password   -e  'show master status' | awk -F' ' 'NR>1 {print $1","$2}')
    result "获取master信息"

    master_file=$(echo ${master_status} |awk -F ',' '{print $1}')
    echo "master_file:"${master_file}

    master_file_position=$(echo ${master_status}|awk -F ',' '{print $2}')
    result "获取master_file_position"
    echo "master_file_position:"${master_file_position}

#    echo "请在终端执行以下命令："
#    SQL="show master status"
#    echo "mysql -uroot -p"${MYSQL_PASS}" -h "${MASTER_HOST}"  -P ${MYSQL_PORT}  --connect-expired-password   -e \"${SQL}\" | awk -F' ' 'NR>1 {print \$1","\$2}'"
#
#    master_file=$(bash -c 'read  -p  "input master_file:" file; echo $file')
#    master_file_position=$(bash -c 'read  -p "input master_file_position:" file_position; echo $file_position')
#    echo "master_file:"$master_file
#    echo "master_file_position:"$master_file_position


    echo "config slave..."
    CHANGE_MATER_SQL="change master to master_host='${MASTER_HOST}',master_user='myslave',master_password='123456',master_log_file='${master_file}',master_log_pos=${master_file_position};"
    echo "CHANGE_MATER_SQL:"${CHANGE_MATER_SQL}

    mysql -uroot -p"${MYSQL_PASS}"  -P ${MYSQL_PORT}  --connect-expired-password  <<EOF
$CHANGE_MATER_SQL
EOF
    result "change master"

    echo "start slave...."
        #mysql -uroot -p"${MYSQL_PASS}" -P ${MYSQL_PORT}  --connect-expired-password -e \"${START_SLAVE_SQL}\" &> /dev/null
    mysql -uroot -p"${MYSQL_PASS}"  -P ${MYSQL_PORT}  --connect-expired-password  <<EOF
start slave
EOF
  result "start slave"


    #检查同步状态
    Slave_IO_Running=$(mysql -uroot -p"${MYSQL_PASS}" -P ${MYSQL_PORT} --connect-expired-password  -e  'show slave status\G' | awk 'NR==12 {print $2}')
    if [ ${Slave_IO_Running} !=  "Yes" ];then
      echo "检查同步状态,Slave_IO_Running:"${Slave_IO_Running}
      exit 1;
    fi
    Slave_SQL_Running=$(mysql -uroot -p"${MYSQL_PASS}" -P ${MYSQL_PORT} --connect-expired-password -e  'show slave status\G' | awk 'NR==13 {print $2}')
    if [ ${Slave_SQL_Running} != "Yes" ];then
      echo "检查同步状态,Slave_SQL_Running:"${Slave_SQL_Running}
      exit 1;
    fi

  fi
  echo "当前节点主从配置完成......"

}

MYSQL_MHA_INSTALL(){
  #wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo
  echo "安装依赖包"
  yum install epel-release --nogpgcheck -y
  echo "安装依赖包2..."
  yum install -y perl-DBD-MySQL \
  perl-Config-Tiny \
  perl-Log-Dispatch \
  perl-Parallel-ForkManager \
  perl-ExtUtils-CBuilder \
  perl-ExtUtils-MakeMaker \
  perl-CPAN

  yum install ncftp -y
  yum install net-tools -y

  #检查依赖软件
  rpm -qa|grep perl-DBD-MySQL
  if [ $? = 1 ]; then
     echo "perl-CPAN安装失败，需要执行：yum install perl-DBD-MySQL"
     #exit 1;
  fi

  rpm -qa|grep perl-Config-Tiny
  if [ $? = 1 ]; then
     echo "perl-CPAN安装失败，需要执行：yum install perl-Config-Tiny"
     #exit 1;
  fi


  rpm -qa|grep perl-Log-Dispatch
  if [ $? = 1 ]; then
     echo "perl-CPAN安装失败，需要执行：yum install perl-Log-Dispatch"
     #exit 1;
  fi


  rpm -qa|grep perl-Parallel-ForkManager
  if [ $? = 1 ]; then
     echo "perl-CPAN安装失败，需要执行：yum install perl-Parallel-ForkManager"
     #exit 1;
  fi


  rpm -qa|grep perl-ExtUtils-CBuilder
  if [ $? = 1 ]; then
     echo "perl-CPAN安装失败，需要执行：yum install perl-ExtUtils-CBuilder"
     #exit 1;
  fi


  rpm -qa|grep perl-ExtUtils-MakeMaker
  if [ $? = 1 ]; then
     echo "perl-CPAN安装失败，需要执行：yum install perl-ExtUtils-MakeMaker"
     #exit 1;
  fi

  rpm -qa|grep perl-CPAN
  if [ $? = 1 ]; then
     echo "perl-CPAN安装失败，需要执行：yum install perl-CPAN"
     #exit 1;
  fi


  #检查是否已安装node
  mha_node="/opt/mha4mysql-node-0.58"
  if [ -d "${mha_node}" ]; then
    echo "${mha_node} already exist"
    #exit 1;

    #检查是否已经编译
    if [ -e "/usr/local/bin/save_binary_logs" ];then
      echo "${mha_node} 已编译"
    else
      # 开始编译
      cd ${mha_node} && perl Makefile.PL make && make install
      if [ $? = 1 ]; then
          echo "编译mha node失败，请手动执行：cd "${mha_node} " && perl Makefile.PL make && make install"
          exit 1;
      fi
    fi

  else
    echo "开始下载mha4mysql-node-0.58.tar.gz ..."
    echo "SHELL_SCRIPT_PATH:"$SHELL_SCRIPT_PATH
    cd $SHELL_SCRIPT_PATH

    wget https://github.com/yoshinorim/mha4mysql-node/releases/download/v0.58/mha4mysql-node-0.58.tar.gz

    echo "开始解压 tar vxzf  mha4mysql-node-0.58.tar.gz -C /opt ..."
    tar vxzf  ${SHELL_SCRIPT_PATH}/mha4mysql-node-0.58.tar.gz -C /opt
    #编译
    echo "开始编译mha node..."
    cd ${mha_node} && perl Makefile.PL make && make install
    if [ $? = 1 ]; then
        echo "编译mha node失败，请手动执行：cd "${mha_node} " && perl Makefile.PL make && make install"
        exit 1;
    fi
  fi

  \cp /usr/local/bin/* /usr/bin
  echo "mha node安装成功"


  #是否需要安装manager
  current_ip=$(hostname -I|awk -F" " '{print $1}')
  if [ ${current_ip} != ${MANAGER_HOST} ]; then
    echo "not manager host,not need install manager"
    return
  fi

  echo "install send_email..."
  install_send_email

  #检查是否已安装manager
  mha_manager="/opt/mha4mysql-manager-0.58"
  if [ -d "${mha_manager}" ]; then
    echo "${mha_manager} already exist"

    #检查是否已经编译
    if [ -e "/usr/local/bin/masterha_check_repl" ];then
      echo "${mha_manager} 已编译"
    else
      # 开始编译
      cd ${mha_manager} && perl Makefile.PL make && make install
      if [ $? = 1 ]; then
          echo "编译mha node失败，请手动执行：cd "${mha_manager} " && perl Makefile.PL make && make install"
          exit 1;
      fi
    fi
  else
    echo "开始下载mha4mysql-manager-0.58.tar.gz ..."
    echo "SHELL_SCRIPT_PATH:"$SHELL_SCRIPT_PATH
    cd $SHELL_SCRIPT_PATH
    #从下载开始
    echo "开始下载mha4mysql-manager-0.58.tar.gz ..."
    wget https://github.com/yoshinorim/mha4mysql-manager/releases/download/v0.58/mha4mysql-manager-0.58.tar.gz

    echo "开始解压 tar vxzf  mha4mysql-node-0.58.tar.gz -C /opt ..."
    tar vxzf  ${SHELL_SCRIPT_PATH}/mha4mysql-manager-0.58.tar.gz -C /opt

    echo "开始编译mha manager..."
    cd ${mha_manager} && perl Makefile.PL make && make install
    if [ $? = 1 ]; then
        echo "编译mha manager失败，请手动执行：cd "${mha_manager} " && perl Makefile.PL make && make install"
        exit 1;
    fi
  fi
  #echo "mha manager安装成功"
  mkdir -p /etc/masterha
  \cp ${SHELL_SCRIPT_PATH}/manager_start.sh /etc/masterha
  \cp -rp ${mha_manager}/samples/scripts /usr/local/bin
  echo "mha manager安装成功"
}

#manager节点配置
MYSQL_MASTER_IP_FAILOVER_CONFIG_BAK(){
  echo "开始配置mha manager..."

  #配置master_ip_failover
  echo "开始配置master_ip_failover"
  cat>/usr/local/bin/master_ip_failover<<EOF
#!/usr/bin/env perl
use strict;
use warnings FATAL => 'all';

use Getopt::Long;

my (
\$command, \$ssh_user, \$orig_master_host, \$orig_master_ip,
\$orig_master_port, \$new_master_host, \$new_master_ip, \$new_master_port
);
#############################添加内容部分#########################################
my \$vip = "${VIR_IP}";           #指定vip的地址
my \$ifdev = "${DEV}";                    #指定vip绑定的网卡
my \$key = "1";                        #指定vip绑定的虚拟网卡序列号
my \$ssh_start_vip = "/sbin/ifconfig \$ifdev:\$key \$vip";   #代表此变量值为ifconfig ens33:1 192.168.223.200
my \$ssh_stop_vip = "/sbin/ifconfig \$ifdev:\$key down";    #代表此变量值为ifconfig ens33:1 192.168.223.200 down
my $exit_code = 0;                      #指定退出状态码为0
##################################################################################
GetOptions(
'command=s' => \$command,
'ssh_user=s' => \$ssh_user,
'orig_master_host=s' => \$orig_master_host,
'orig_master_ip=s' => \$orig_master_ip,
'orig_master_port=i' => \$orig_master_port,
'new_master_host=s' => \$new_master_host,
'new_master_ip=s' => \$new_master_ip,
'new_master_port=i' => \$new_master_port,
);

exit &main();

sub main {

print "\n\nIN SCRIPT TEST====\$ssh_stop_vip==\$ssh_start_vip===\n\n";

if ( \$command eq "stop" || \$command eq "stopssh" ) {

my $exit_code = 1;
eval {
print "Disabling the VIP on old master: \$orig_master_host \n";
\&stop_vip();
\$exit_code = 0;
};
if (\$@) {
warn "Got Error: \$@\n";
exit \$exit_code;
}
exit \$exit_code;
}
elsif ( \$command eq "start" ) {

my \$exit_code = 10;
eval {
print "Enabling the VIP - \$vip on the new master - \$new_master_host \n";
\&start_vip();
\$exit_code = 0;
};
if (\$@) {
warn \$@;
exit $exit_code;
}
exit $exit_code;
}
elsif ( \$command eq "status" ) {
print "Checking the Status of the script.. OK \n";
exit 0;
}
else {
&usage();
exit 1;
}
}
sub start_vip() {
`ssh \$ssh_user\@\$new_master_host \" \$ssh_start_vip \"`;
}
## A simple system call that disable the VIP on the old_master
sub stop_vip() {
`ssh \$ssh_user\@\$orig_master_host \" \$ssh_stop_vip \"`;
}

sub usage {
print
"Usage: master_ip_failover --command=start|stop|stopssh|status --orig_master_host=host --orig_master_ip=ip --orig_master_port=port --new_master_host=host --new_master_ip=ip --new_master_port=port\n";
}

EOF

}

MYSQL_MASTER_IP_FAILOVER_CONFIG(){
\cp ${SHELL_SCRIPT_PATH}/master_ip_failover /usr/local/bin/master_ip_failover
sed -i "12c my \$vip = \"${VIR_IP}\"; " /usr/local/bin/master_ip_failover
sed -i "13c my \$ifdev = \"${DEV}\"; " /usr/local/bin/master_ip_failover
chmod 755 /usr/local/bin/master_ip_failover
}

MYSQL_MASTERHA_CONFIG(){
  mkdir -p ${MYSQL_DIR}/masterha/app
  #创建 MHA 软件目录并复制配置文件，使用app.cnf配置文件来管理 mysql 节点服务器，配置文件一般放在/etc/目录下，需要修改对应的ip
  mkdir -p /etc/masterha

  cat > /etc/masterha/app.cnf << EOF
[server default]
manager_log=${MYSQL_DIR}/masterha/app/manager.log
manager_workdir=${MYSQL_DIR}/masterha
master_binlog_dir=${MYSQL_DIR}/data
master_ip_failover_script=/usr/local/bin/master_ip_failover
master_ip_online_change_script=/usr/local/bin/master_ip_online_change
password=123456
ping_interval=1
remote_workdir=/tmp
repl_password=123456
repl_user=myslave
secondary_check_script=/usr/local/bin/masterha_secondary_check -s ${SLAVE1_HOST} -s ${SLAVE2_HOST}
shutdown_script=""
ssh_user=root
user=mha
report_script=${MYSQL_DIR}/masterha/manager_report_script

[server1]
candidate_master=1
check_repl_delay=0
hostname=${MASTER_HOST}
port=${MYSQL_PORT}

[server2]
candidate_master=1
check_repl_delay=0
hostname=${SLAVE1_HOST}
port=${MYSQL_PORT}

[server3]
hostname=${SLAVE2_HOST}
port=${MYSQL_PORT}

EOF

#如果发生master切换
#当前master是${MASTER_HOST}
app_bak1=$(echo ${MASTER_HOST} |md5sum |awk '{print $1}')
\cp /etc/masterha/app.cnf  /etc/masterha/${app_bak1}

#当前master是${SLAVE1_HOST}
app_bak2=$(echo ${SLAVE1_HOST} |md5sum |awk '{print $1}')
\cp /etc/masterha/app.cnf  /etc/masterha/${app_bak2}
sed -i "12c secondary_check_script=/usr/local/bin/masterha_secondary_check -s ${MASTER_HOST} -s ${SLAVE2_HOST}" /etc/masterha/${app_bak2}

#当前master是${SLAVE2_HOST}
app_bak3=$(echo ${SLAVE2_HOST} |md5sum |awk '{print $1}')
\cp /etc/masterha/app.cnf  /etc/masterha/${app_bak3}
sed -i "12c secondary_check_script=/usr/local/bin/masterha_secondary_check -s ${MASTER_HOST} -s ${SLAVE1_HOST}" /etc/masterha/${app_bak3}

#拷贝启动脚本
\cp ${SHELL_SCRIPT_PATH}/manager_start.sh /etc/masterha/manager_start.sh
chmod 755 /etc/masterha/manager_start.sh
}


#每个host都需要写恢复脚本
WIRTE_DOWN_RECOVER(){
  echo "SHELL_SCRIPT_PATH:"$SHELL_SCRIPT_PATH
  \cp  ${SHELL_SCRIPT_PATH}/mha_master_2_slave.sh ${MYSQL_DIR}
  sed -i "3c manager_host=${MANAGER_HOST}" ${MYSQL_DIR}/mha_master_2_slave.sh
  sed -i "4c MYSQL_DIR=${MYSQL_DIR}" ${MYSQL_DIR}/mha_master_2_slave.sh
  chmod 755  ${MYSQL_DIR}/mha_master_2_slave.sh
}

Write_Mysql_Service(){
  cat >  /usr/lib/systemd/system/mysql.service << EOF
[Unit]
Description=MySQL Server
After=network.target
[Service]
Type=forking
User=root
Group=root
ExecStart=/bin/sh -c 'env GOTRACEBACK=crash ${BASE_DIR}/bin/mysqld --basedir=${BASE_DIR} --datadir=${DATA_DIR} --plugin-dir=${BASE_DIR}/lib/plugin --user=root --log-error=${LOG_DIR}/mysqld.log --pid-file=${DATA_DIR}/localhost.localdomain.pid --socket=${DATA_DIR}/mysql.sock --port=3306 >> ${LOG_DIR}/mysql_start.log 2>&1 &'
LimitNOFILE=50000
Restart=always
RestartSec=11
[Install]
WantedBy=multi-user.target

EOF

systemctl enable /usr/lib/systemd/system/mysql.service
systemctl daemon-reload
systemctl start /usr/lib/systemd/system/mysql.service
}

Write_Manager_Service(){
  cat >  /usr/lib/systemd/system/mhamanager.service << EOF
[Unit]
Description=MHA Manager
After=network.target

[Service]
Type=simple
User=root
Group=root
ExecStart=nohup masterha_manager --conf=/etc/masterha/app.cnf --remove_dead_master_conf --ignore_last_failover < /dev/null > ${MYSQL_DIR}/masterha/app/manager.log 2>&1 &
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target

EOF
systemctl enable /usr/lib/systemd/system/mhamanager.service
systemctl daemon-reload
systemctl start /usr/lib/systemd/system/mhamanager.service

}

##################################################################################################
open_firewall_port $MYSQL_PORT
# mysql安装
MYSQL_INSTALL

#systemd配置
Write_Mysql_Service

#主从配置
MYSQL_MASTER_SLAVE_CONFIG

#mha组件安装
MYSQL_MHA_INSTALL

#每个节点都需要有恢复脚本
WIRTE_DOWN_RECOVER

#master上设置虚拟ip
cur_ip=$(hostname -I|awk -F" " '{print $1}')
if [ ${cur_ip} = ${MASTER_HOST} ];then
  echo "开始设置虚拟ip"
  set_vir_ip
fi

#判断是否安装manager,如果当前ip是manager机器，则安装
cur_ip=$(hostname -I|awk -F" " '{print $1}')
if [ ${cur_ip} = ${MANAGER_HOST} ];then
  echo "mysql_master_ip_failover_config"
  MYSQL_MASTER_IP_FAILOVER_CONFIG

  echo "mysql_masterha_config"
  MYSQL_MASTERHA_CONFIG
  echo "配置manager systemd..."
  #Write_Manager_Service
  echo "start masterha manager.."
  sh /etc/masterha/manager_start.sh
fi
echo "********************************** 当前节点配置成功 **********************************"


