#!/bin/bash
  #启动
MYSQL_DIR="/data/zdlz/mysql"

echo "开始启动 masterha manager"
nohup masterha_manager --conf=/etc/masterha/app.cnf --remove_dead_master_conf --ignore_last_failover < /dev/null > ${MYSQL_DIR}/masterha/app/manager.log 2>&1 &
if [ $? = 1 ];then
  echo "请执行以下命令，检查mysql状态："
  echo "masterha_check_ssh -conf=/etc/masterha/app.cnf"
  echo "masterha_check_repl -conf=/etc/masterha/app.cnf"
fi

manager_process=$(ps -ef |grep masterha_manager |grep -v grep|wc -l)
if [ ${manager_process} = 1 ];then
  echo "masterha_manager 启动成功"
else
  echo "masterha_manager 启动失败,请检查："
  echo "masterha_check_status --conf=/etc/masterha/app.cnf"
  echo "masterha_check_repl -conf=/etc/masterha/app.cnf"
fi