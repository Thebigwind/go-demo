#!/bin/bash

MYSQL_DIR=/data/zdlz/mysql
BASE_DIR=/data/zdlz/mysql/mysql-8.0.24
DATA_DIR=/data/zdlz/mysql/data
LOG_DIR=/data/zdlz/mysql/log

#echo "comfirm clean all?"
#confirm=$(bash -c 'read  -p  "comfirm clean all?(yes or no):" clean; echo $clean')
#if [ ${confirm} != "yes" ];then
#  echo "not clean,exit"
#  exit
#fi

echo "开始清理。。"
#1.清理mysql
rm -f /usr/lib/systemd/system/mysql.service
rm -f /usr/lib/systemd/system/mhamanager.service
systemctl daemon-reload
systemctl stop mysql
systemctl stop mysqld
systemctl stop mhamanager

rm -rf ${BASE_DIR}
rm -rf ${DATA_DIR}
rm -rf ${MYSQL_DIR}/masterha
rm -r ${MYSQL_DIR}/change.log
rm -f /etc/my.cnf
rm -f /etc/init.d/mysqld
rm -rf /etc/masterha
#rm  -rf /usr/local/bin/*
rm -f  /usr/local/bin/apply_diff_relay_logs
rm -f  /usr/local/bin/filter_mysqlbinlog
rm -f  /usr/local/bin/masterha_check_repl
rm -f  /usr/local/bin/masterha_check_ssh
rm -f  /usr/local/bin/masterha_check_status
rm -f  /usr/local/bin/masterha_conf_host
rm -f  /usr/local/bin/masterha_manager
rm -f  /usr/local/bin/masterha_master_monitor
rm -f  /usr/local/bin/masterha_master_switch
rm -f  /usr/local/bin/masterha_secondary_check
rm -f  /usr/local/bin/masterha_stop
rm -f  /usr/local/bin/master_ip_failover
rm -f  /usr/local/bin/purge_relay_logs
rm -f  /usr/local/bin/save_binary_logs
rm /usr/bin/mysql
rm /usr/bin/mysqlbinlog
rm ${MYSQL_DIR}/mha_master_2_slave.sh
ifconfig eth0:1 down
#ps -ef | grep mysql | grep -v grep | awk '{print $2}'|xargs kill -9
#kill -9 $pid
