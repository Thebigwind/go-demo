#!/bin/bash

manager_host="10.10.10.224"
MYSQL_DIR=/data/zdlz/mysql
#mysql进程数赋值
mysqlpid=`ps -ef | grep [m]ysql | wc -l`

#判断MySQL是否假死，如果假死杀掉重启，如果关闭则启动
if [ $mysqlpid -eq 0 ];then
    echo  $(date +"%Y%m%d%H%M%S":)"开始拉起mysql..." >> ${MYSQL_DIR}/change.log
    systemctl start mysql
else
    pkill mysqld
    echo  $(date +"%Y%m%d%H%M%S":)"开始拉起mysql....." >> ${MYSQL_DIR}/change.log
    systemctl start mysql
fi

#获取配置主从语句
change=`ssh ${manager_host} "grep 'CHANGE MASTER TO' ${MYSQL_DIR}/masterha/app/manager.log "| tail -1 | sed 's#xxx#123456#g'  | awk -F: '{print $4}'`
echo $(date +"%Y%m%d%H%M%S":)${change} >> ${MYSQL_DIR}/change.log

sleep 8

#4.执行主从语句并启动线程
#echo  $(date +"%Y%m%d%H%M%S":)"mysql -umha -p123456 -e \"$change; start slave\"" >> ${MYSQL_DIR}/change.log
mysql -umha -p123456  --connect-expired-password  <<EOF
$change; start slave;
EOF

if [ $? -eq 0 ]; then
  echo  $(date +"%Y%m%d%H%M%S":)"change执行成功。" >> ${MYSQL_DIR}/change.log
else
  echo  $(date +"%Y%m%d%H%M%S":)"change执行失败" >> ${MYSQL_DIR}/change.log
  exit 1
fi

