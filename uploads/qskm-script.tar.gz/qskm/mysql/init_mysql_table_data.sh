#!/bin/bash
SHELL_SCRIPT_PATH=$(cd $(dirname $0); pwd)
echo "SHELL_SCRIPT_PATH:"$SHELL_SCRIPT_PATH

Mysql_Env_File=${SHELL_SCRIPT_PATH}/mysql.env
MYSQL_HOST=$(cat $Mysql_Env_File|grep VirtualIp|awk -F '=' '{print $2}')
MYSQL_PORT=$(cat $Mysql_Env_File|grep MysqlPort|awk -F '=' '{print $2}')
MYSQL_PASSWORD=$(cat $Mysql_Env_File|grep MysqlPass|awk -F '=' '{print $2}')
SQL_TABLE_FILE=/data/qskm/deploy/init_mysql_table.sql
SQL_DATA_FILE=/data/qskm/deploy/init_mysql_data.sql

#文件是否存在
if [ -e $SQL_TABLE_FILE ];then
  echo "初始化init_mysql_table.sql "
  mysql -h "$MYSQL_HOST" -uroot -p"$MYSQL_PASSWORD" -P ${MYSQL_PORT} < "$SQL_TABLE_FILE"
else
  echo "SQL_TABLE_FILE 不存在："${SQL_TABLE_FILE}
fi

if [ -e $SQL_DATA_FILE ];then
  echo "初始化init_mysql_data.sql "
  mysql -h "$MYSQL_HOST" -uroot -p"$MYSQL_PASSWORD" -P ${MYSQL_PORT}  < "$SQL_DATA_FILE"
else
  echo "SQL_TABLE_FILE 不存在："${SQL_TABLE_FILE}
fi

