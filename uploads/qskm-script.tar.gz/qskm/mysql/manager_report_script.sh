#!/bin/bash
#down掉的master，重新拉起，变成slave
MYSQL_DIR="/data/zdlz/mysql"
echo $(date +"%Y%m%d%H%M%S":)"manager_report_script被调用...." >  ${MYSQL_DIR}/masterha/report.
#发送邮件告警
sh ${MYSQL_DIR}/masterha/send_email > /data/zdlz/mysql/email.log 2>&1

date_time=$(date +"%Y%m%d%H%M%S")
cp ${MYSQL_DIR}/masterha/app/manager.log ${MYSQL_DIR}/masterha/app/$date_time.log

mha_master_2_slave=${MYSQL_DIR}/mha_master_2_slave.sh
manager_log=${MYSQL_DIR}/masterha/app/manager.log
down_master_ip=$(tail -n 20  ${manager_log} |grep "Invalidated master IP"|awk -F ' ' '{print $6}'|awk -F '(' '{print $1}')
current_master_ip=$(tail -n 8 ${manager_log} |grep "Master failover to"|grep "successfully"|awk -F ' ' '{print $4}'|awk -F '(' '{print$1}')
echo $(date +"%Y%m%d%H%M%S":)"down_master_ip is:"${down_master_ip} >> ${MYSQL_DIR}/masterha/report.log
echo $(date +"%Y%m%d%H%M%S":)"current_master_ip is:"${current_master_ip} >>  ${MYSQL_DIR}/masterha/report.log

if  [ -z $down_master_ip ];then
  echo $(date +"%Y%m%d%H%M%S":)"获取down_master_ip失败，切换失败" >>  ${MYSQL_DIR}/masterha/report.log
  exit 1;
fi

if  [ -z $current_master_ip ];then
    echo $(date +"%Y%m%d%H%M%S":)"获取current_master_ip失败，切换失败" >>  ${MYSQL_DIR}/masterha/report.log
  exit 1;
fi

echo $(date +"%Y%m%d%H%M%S":)"开始拉起down掉的master"  >>  ${MYSQL_DIR}/masterha/report.log
ssh $down_master_ip sh $mha_master_2_slave
echo "ssh $down_master_ip sh $mha_master_2_slave" >>  ${MYSQL_DIR}/masterha/report.log
if [ $? = 1 ];then
  echo "down master拉起失败"
  echo $(date +"%Y%m%d%H%M%S":)"down master拉起失败" >>  ${MYSQL_DIR}/masterha/report.log
  exit 1;
fi
echo $(date +"%Y%m%d%H%M%S":)"拉起down掉的master结束"  >>  ${MYSQL_DIR}/masterha/report.log

sleep 3
#重新启动manager
echo $(date +"%Y%m%d%H%M%S":)"更换配置文件" >> ${MYSQL_DIR}/masterha/report.log
app_bak=$(echo ${current_master_ip} |md5sum |awk '{print $1}')
echo $(date +"%Y%m%d%H%M%S":)"app_bak:"$app_bak >> ${MYSQL_DIR}/masterha/report.log
\cp /etc/masterha/${app_bak} /etc/masterha/app.cnf

echo "重新启动 masterha_manager。。。"  >> ${MYSQL_DIR}/masterha/report.log

nohup masterha_manager --conf=/etc/masterha/app.cnf --remove_dead_master_conf --ignore_last_failover < /dev/null > ${MYSQL_DIR}/masterha/app/manager.log 2>&1 &
if [ $? = 1 ];then
    echo $(date +"%Y%m%d%H%M%S":)"启动失败，请执行以下命令，检查mysql状态：" >>  ${MYSQL_DIR}/masterha/report.log
    echo "masterha_check_ssh -conf=/etc/masterha/app.cnf" >>  ${MYSQL_DIR}/masterha/report.log
    echo "masterha_check_repl -conf=/etc/masterha/app.cnf" >>  ${MYSQL_DIR}/masterha/report.log
    echo "masterha_check_status --conf=/etc/masterha/app.cnf" >>  ${MYSQL_DIR}/masterha/report.log
else
  echo $(date +"%Y%m%d%H%M%S":)"masterha_manager已启动。。。" >>  ${MYSQL_DIR}/masterha/report.log
  echo $(date +"%Y%m%d%H%M%S":)"以下命令检查状态：masterha_check_status --conf=/etc/masterha/app.cnf" >>  ${MYSQL_DIR}/masterha/report.log
fi

