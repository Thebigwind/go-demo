# QSND
## 前置工作
### 0.检查3台机器是否设置了repo源，如果没有设置，需要设置下
    cat  /etc/yum.repos.d/epel.repo
    如果内容为空，则需要设置：  
    wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo
    然后再次查看，则已经有内容：
    cat  /etc/yum.repos.d/epel.repo

### 1.将部署脚本目录qskm拷贝到3台机器的相同的目录下，如/data/qskm

### 2.软件包qskm.tar拷贝到/data/qskm目录下，并解压 tar -vxf qskm.tar

### 3. 3台机器需要配置root的免密登录,如果不清楚免密，请百度查询
 #### （1）在所有的机器上执行以下命令
    cd ~
    
    ssh-keygen -t rsa #一路回车
    
    touch ~/.ssh/authorized_keys
    cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
    
    chmod 600 ~/.ssh/authorized_keys
#### （2）公钥拷贝 把公钥~/.ssh/id_rsa.pub拷贝到其它机器上的 ~/.ssh/authorized_keys

#### （3）执行完成后需要在每台机器上测试一遍，看是否配置成功。执行 ssh root@10.10.10.214（其他机器的IP） ，如果可以直接登录，输入 ip a 发现IP确实变成了登录的那台，证明互信建立成功。

### 4.在任意一台机器行安装 python的 pip,以及解析yaml的包
      yum install python3 -y
      yum install python-pip3
      pip3 install pyyaml

## 5.编写配置文件qskm.yml, 该配置文件配置了高可用的主从，端口号，密码，数据目录等信息

## 6.执行 python3 qskm_hight_install.py ,生成各个高可用组件的配置文件,并且按依赖顺序安装
    python3 qskm_hight_install.py   

#### 安装顺序
    1.当前节点mongo
    2.拷贝文件到其它节点
    3.其它节点mongo
    4.mysql master
    5.mysql slave1
    6.mysql slave2
    7.redis master
    8.redis 其它节点
    9.nginx
    10.qskm 

## 需要卸载重新部署时，执行以下命令可卸载全部：
    python3 qskm_hight_clean.py


## 该脚本同时支持只安装或卸载一个组件，如：mysql,mongo,redis,nginx,qskm
    安装mysql:   python3 qskm_hight_install.py mysql
    卸载mysql:   python3 qskm_hight_clean.py mysql

    安装mongo:   python3 qskm_hight_install.py mongo
    卸载mongo:   python3 qskm_hight_clean.py mongo

    安装redis:   python3 qskm_hight_install.py redis
    卸载redis:   python3 qskm_hight_clean.py redis

    安装nginx:   python3 qskm_hight_install.py nginx
    卸载nginx:   python3 qskm_hight_clean.py nginx

    安装qskm:   python3 qskm_hight_install.py qskm
    卸载qskm:   python3 qskm_hight_clean.py qskm