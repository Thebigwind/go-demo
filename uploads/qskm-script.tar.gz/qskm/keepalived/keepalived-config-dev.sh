#!/bin/bash 
#配置
keepalived_user=work
keepalived_group=work
keepalived_datadir=/data/keepalived
