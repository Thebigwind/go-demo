#!/bin/bash 
#配置
configshell=./keepalived-config.sh
scriptenv=""
if [ "$1" == "--env" ] && [ "$2" != "" ]
then
	scriptenv=$2
	configshell=./keepalived-config-$2.sh
	if [ ! -e $configshell ]
	then
		echo "config file $configshell not exist!"
		exit 1
	fi
fi
echo "use config file $configshell"
source $configshell
#未使用
smtp_server=192.168.200.1
notification_email_from=test@test.cc
notification_email=test@test.cc
sbinhad=`echo $PATH | grep '/usr/sbin' | wc -l`
if [ "$sbinhad" = "0" ]
then
	PATH=$PATH:/usr/sbin
fi
#安装
sudo passwd -S $keepalived_user &>/dev/null
if [ $? -ne 0 ]
then
	echo "Unknown user name $keepalived_user"
	exit 1
fi
tmpdir=/tmp/keepalived
mkdir -p $tmpdir
if [ ! -e /usr/lib/systemd/system/keepalived.service ]
then
	is_kylin=`cat /etc/system-release | grep Tercel | wc -l`
	if [ "$is_kylin" == "1" ]
	then
		if [ ! -s $tmpdir/keepalived-2.1.5-6.el8.x86_64.rpm ]
		then
			wget --no-check-certificate https://vault.centos.org/centos/8/AppStream/x86_64/os/Packages/keepalived-2.1.5-6.el8.x86_64.rpm -O $tmpdir/keepalived-2.1.5-6.el8.x86_64.rpm
		fi
		sudo rpm -i $tmpdir/keepalived-2.1.5-6.el8.x86_64.rpm
		if [ $? -ne 0 ]
		then
			echo "keepalived安装失败"
			exit 1
		fi
	else
		if [ ! -s $tmpdir/keepalived-1.3.5-19.el7.x86_64.rpm ]
		then
			wget --no-check-certificate http://mirror.centos.org/centos/7/os/x86_64/Packages/keepalived-1.3.5-19.el7.x86_64.rpm -O $tmpdir/keepalived-1.3.5-19.el7.x86_64.rpm
		fi
		sudo rpm -i $tmpdir/keepalived-1.3.5-19.el7.x86_64.rpm
		if [ $? -ne 0 ]
		then
			sudo yum install keepalived -y
			if [ $? -ne 0 ]
			then
				echo "keepalived安装失败"
				exit 1
			fi
		fi
	fi
fi
#替换配置
sudo chown $keepalived_user.$keepalived_group -R /etc/keepalived
sudo -u $keepalived_user cp -f ./config/keepalived.conf /etc/keepalived/keepalived.conf
if [ ! -s /etc/keepalived/keepalived_redis.conf ]
then
	sudo -u $keepalived_user cp -f ./config/keepalived_redis.conf /etc/keepalived/keepalived_redis.conf
fi
if [ ! -s /etc/keepalived/keepalived_nginx.conf ]
then
	sudo -u $keepalived_user cp -f ./config/keepalived_nginx.conf /etc/keepalived/keepalived_nginx.conf
fi
sudo mkdir -p $keepalived_datadir
sudo chown $keepalived_user.$keepalived_group -R $keepalived_datadir
sudo chmod 775 $keepalived_datadir
sudo chcon -R -u system_u $keepalived_datadir 2>/dev/null
sudo chcon -R -t var_run_t $keepalived_datadir 2>/dev/null
#sed -i "s/smtp_server 192.168.200.1/smtp_server $smtp_server/g" /etc/keepalived/keepalived.conf
#sed -i "s/notify@test.cc/$notification_email/g" /etc/keepalived/keepalived.conf
#sed -i "s/from@test.cc/$notification_email_from/g" /etc/keepalived/keepalived.conf
sudo sed -i "s/script_user .*/script_user $keepalived_user/g" /etc/keepalived/keepalived.conf
opts="-P -D -S 1 -p $keepalived_datadir/keepalived.pid -r $keepalived_datadir/vrrp.pid -c $keepalived_datadir/checker.pid"
sudo sed -i "s#KEEPALIVED_OPTIONS=\".*\"#KEEPALIVED_OPTIONS=\"$opts\"#g" /etc/sysconfig/keepalived
sudo cp -f ./config/keepalived.service /usr/lib/systemd/system/keepalived.service
sudo sed -i "s#PIDFile=.*.pid#PIDFile=$keepalived_datadir/keepalived.pid#g" /usr/lib/systemd/system/keepalived.service
#sudo sed -i "s/User=.*/User=$keepalived_user/g" /usr/lib/systemd/system/keepalived.service
#sudo sed -i "s/Group=.*/Group=$keepalived_group/g" /usr/lib/systemd/system/keepalived.service
vrrphad=`sudo iptables -L -v | grep vrrp | wc -l`
if [ "$vrrphad" == "0" ]
then
	sudo firewall-cmd --add-rich-rule='rule protocol value="vrrp" accept' --permanent
	sudo firewall-cmd --reload
fi
sudo systemctl daemon-reload
sudo systemctl enable keepalived
#运行
#seenforce=`sestatus | grep Current | grep enforcing | wc -l`
#seenforce=`getenforce | grep Enforcing | wc -l`
seenforce=`getenforce`
if [ "$seenforce" != "Disabled" ]
then
	which semanage &>/dev/null
	if [ $? -ne 0 ]
	then
		sudo yum install policycoreutils-python-2.5-34.el7.x86_64 -y
	fi
	seperm=`sudo semanage permissive -l | grep keepalived_t | wc -l`
	if [ "$seperm" == "0" ]
	then
		sudo semanage permissive -a keepalived_t
	fi
fi
sudo systemctl stop keepalived
sudo systemctl start keepalived
keeppid=`pgrep keepalived | sort | head -1`
if [ "$keeppid" = "" ]
then
	echo "keepalived启动失败"
else
	echo "keepalived已启动"
fi
