#!/bin/bash
systemctl stop keepalived
systemctl disable keepalived
yum erase keepalived -y
rm -drf /data/keepalived
rm -drf /tmp/keepalived
