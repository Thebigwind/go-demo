#!/bin/bash 
#配置
keepalived_user=zdlz
keepalived_group=zdlz
keepalived_datadir=/data/keepalived
