#!/bin/bash 
#配置
redis_ver=6.2.13
redis_user=zdlz
redis_group=zdlz
redis_port=16379
redis_passwd="123456"
redis_pidfile=/data/redis/redis-${redis_port}.pid
redis_logfile=/data/redis/redis-${redis_port}.log
redis_datadir=/data/redis/data
redis_master_ip=10.10.10.164
redis_backup_ips="10.10.10.154 10.10.10.242"
redis_vip=10.10.10.15
redis_virtual_router_id=11
