#!/bin/bash
systemctl stop keepalived
systemctl disable keepalived
yum erase keepalived -y
systemctl stop redis
systemctl disable redis
yum erase redis -y
rm -drf /data/redis
rm -drf /data/keepalived
rm -f /etc/redis/redis.conf
echo "" > /etc/keepalived/keepalived_redis.conf
rm -drf /etc/keepalived/keepalived_redis_script
rm -drf /tmp/redis
rm -drf /tmp/keepalived
