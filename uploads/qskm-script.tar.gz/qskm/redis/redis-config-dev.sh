#!/bin/bash 
#配置
redis_ver=6.2.13
redis_user=work
redis_group=work
redis_port=16379
redis_passwd="123456"
redis_pidfile=/data/redis/redis-${redis_port}.pid
redis_logfile=/data/redis/redis-${redis_port}.log
redis_datadir=/data/redis/data
redis_master_ip=192.168.36.3
redis_backup_ips="192.168.36.4 192.168.36.5"
redis_vip=192.168.36.30
redis_virtual_router_id=11
