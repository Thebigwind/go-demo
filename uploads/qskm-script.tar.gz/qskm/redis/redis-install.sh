#!/bin/bash 
#配置
configshell=./redis-config.sh
scriptenv=""
if [ "$1" == "--env" ] && [ "$2" != "" ]
then
	scriptenv=$2
	configshell=./redis-config-$2.sh
	if [ ! -e $configshell ]
	then
		echo "config file $configshell not exist!"
		exit 1
	fi
fi
echo "use config file $configshell"
source $configshell
sbinhad=`echo $PATH | grep '/usr/sbin' | wc -l`
if [ "$sbinhad" = "0" ]
then
	PATH=$PATH:/usr/sbin
fi
#安装
exist=`redis-cli -v 2>/dev/null | grep $redis_ver | wc -l`
if [ "$exist" = "0" ]
then
	tmpdir=/tmp/redis
	mkdir -p $tmpdir
	redis_rpm=redis-${redis_ver}-1.el7.remi.x86_64.rpm
	if [ ! -s $tmpdir/$redis_rpm ]
	then
		which wget &>/dev/null
		if [ $? -ne 0 ]
		then
			sudo yum install wget -y
		fi
		wget --no-check-certificate https://rpms.remirepo.net/enterprise/7/remi/x86_64/$redis_rpm -O $tmpdir/$redis_rpm
	fi
	sudo rpm -i $tmpdir/$redis_rpm
	if [ $? -ne 0 ]
	then
		is_kylin=`cat /etc/system-release | grep Tercel | wc -l`
		if [ "$is_kylin" == "1" ]
		then
			wget --no-check-certificate https://pkgs.dyn.su/el8/modular/x86_64/redis/redis-7.0.5-1.el8.x86_64.rpm -O $tmpdir/redis-7.0.5-1.el8.x86_64.rpm
			sudo rpm -i $tmpdir/redis-7.0.5-1.el8.x86_64.rpm
			if [ `redis-cli -v | wc -l` = 0 ]
			then
				echo "redis安装失败"
				exit 1
			fi
		else
			echo "redis安装失败"
			exit 1
		fi
	fi
fi
#替换配置
sudo chown $redis_user.$redis_group -R /etc/redis
sudo chmod 775 /etc/redis
sudo -u $redis_user cp -f ./config/redis.conf /etc/redis/redis.conf
sudo mkdir -p `dirname $redis_pidfile` `dirname $redis_logfile` $redis_datadir
sudo chown $redis_user.$redis_group -R `dirname $redis_pidfile` `dirname $redis_logfile` $redis_datadir
sudo chcon -R -u system_u `dirname $redis_pidfile` `dirname $redis_logfile` $redis_datadir 2>/dev/null
sudo chcon -R -t redis_log_t `dirname $redis_pidfile` `dirname $redis_logfile` $redis_datadir 2>/dev/null
sudo sed -i "s/port 6379/port $redis_port/g" /etc/redis/redis.conf
sudo sed -i "s#pidfile /var/run/redis_6379.pid#pidfile $redis_pidfile#g" /etc/redis/redis.conf
sudo sed -i "s#logfile /var/log/redis/redis.log#logfile $redis_logfile#g" /etc/redis/redis.conf
sudo sed -i "s#dir /var/lib/redis#dir $redis_datadir#g" /etc/redis/redis.conf
if [ "$redis_passwd" != "" ]
then
	sudo sed -i "s/# requirepass foobared/requirepass $redis_passwd/g" /etc/redis/redis.conf
	sudo sed -i "s/# masterauth.*/masterauth $redis_passwd/g" /etc/redis/redis.conf
fi
sudo cp -f ./config/redis.service /usr/lib/systemd/system/redis.service
sudo sed -i "s/User=.*/User=$redis_user/g" /usr/lib/systemd/system/redis.service
sudo sed -i "s/Group=.*/Group=$redis_group/g" /usr/lib/systemd/system/redis.service
#firewall
portyes=`sudo firewall-cmd --query-port=$redis_port/tcp --permanent`
if [ "$portyes" == "no" ]
then
	sudo firewall-cmd --add-port=$redis_port/tcp --permanent
	sudo firewall-cmd --reload
fi
#systemd
sudo systemctl daemon-reload 
sudo systemctl enable redis
#运行
sudo systemctl stop redis
sudo systemctl start redis
#配置keepalived
if [ ! -e /etc/systemd/system/multi-user.target.wants/keepalived.service ]
then
	oldpwd=`pwd`
	cd ../keepalived/
	if [ "$scriptenv" = "" ]
	then
		sh keepalived-install.sh
	else
		sh keepalived-install.sh --env $scriptenv
	fi
	if [ $? -ne 0 ]
	then
		exit 1
	fi
	cd $oldpwd
fi
sudo -u $redis_user cp -f ./config/keepalived_redis.conf /etc/keepalived/keepalived_redis.conf
sudo chmod 644 /etc/keepalived/keepalived_redis.conf
sudo mkdir -p /etc/keepalived/keepalived_redis_script
sudo chown $redis_user.$redis_group -R /etc/keepalived/keepalived_redis_script
sudo -u $redis_user cp -f ./config/keepalived_redis_script/* /etc/keepalived/keepalived_redis_script/
for f in `ls /etc/keepalived/keepalived_redis_script/*.sh`
do
	sudo sed -i "s#source ./redis-config.sh#source /etc/keepalived/keepalived_redis_script/redis-config.sh#g" $f
	sudo -u $redis_user chmod +x $f
done
sudo -u $redis_user cp -f $configshell /etc/keepalived/keepalived_redis_script/redis-config.sh
local_ip=""
netif=""
for ip in `echo "$redis_master_ip $redis_backup_ips" | cut -d ' ' -f 1-`
do
	netif=`ip a | grep "$ip/" | rev | cut -d ' ' -f 1 | rev`
	if [ "$netif" != "" ]
	then
		local_ip=$ip
		break
	fi
done
if [ "$netif" = "" ]
then
	echo "$redis_master_ip $redis_backup_ips not exist!"
	exit 1
fi
priority=90
if [ "$local_ip" = "$redis_master_ip" ]
then
	priority=100
fi
sudo sed -i "s/interface.*/interface $netif/g" /etc/keepalived/keepalived_redis.conf
sudo sed -i "s/priority.*/priority $priority/g" /etc/keepalived/keepalived_redis.conf
sudo sed -i "s/virtual_router_id 1/virtual_router_id $redis_virtual_router_id/g" /etc/keepalived/keepalived_redis.conf
sudo sed -i "s/192.168.56.233/$redis_vip/g" /etc/keepalived/keepalived_redis.conf
keeppid=`pgrep keepalived | sort | head -1`
if [ "$keeppid" = "" ]
then
	sudo systemctl start keepalived
else
	sudo kill -1 $keeppid
fi
#ok?
redispid=`pgrep redis | sort | head -1`
if [ "$redispid" = "" ]
then
	echo "redis启动失败"
else
	echo "redis已启动"
fi
