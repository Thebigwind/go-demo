#!/bin/bash 
source ./redis-config.sh
LOGFILE=`dirname $redis_logfile`/keepalived-check.log
role=`redis-cli -h 127.0.0.1 -p $redis_port -a $redis_passwd info replication | grep 'role:' | sed s/[[:space:]]//g`
if [ "$role" != "" ]; then
    echo `date` "check ok: $role" >> $LOGFILE 2>&1
else
    echo `date` "check fail: $role" >> $LOGFILE 2>&1
    exit 1
fi
vipfound=`ip a | grep " $redis_vip/" | wc -l`
if [ "$vipfound" = "1" ]
then
    if [ "$role" = "role:slave" ]; then
        echo `date` "vip found: $redis_vip" >> $LOGFILE
        echo `date` "slaveof no one" `redis-cli -h 127.0.0.1 -p $redis_port -a $redis_passwd SLAVEOF NO ONE` >> $LOGFILE
    fi
else
    if [ "$role" = "role:master" ]; then
        echo `date` "vip not found: $redis_vip" >> $LOGFILE
        echo `date` "local 127.0.0.1 slaveof $redis_vip $redis_port" `redis-cli -h 127.0.0.1 -p $redis_port -a $redis_passwd SLAVEOF $redis_vip $redis_port` >> $LOGFILE
    fi
fi
exit 0