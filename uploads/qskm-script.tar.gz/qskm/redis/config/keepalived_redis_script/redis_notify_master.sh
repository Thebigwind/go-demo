#!/bin/bash
source ./redis-config.sh
LOGFILE=`dirname $redis_logfile`/keepalived-notify.log
echo `date` "notify master" >> $LOGFILE
echo `date` "slaveof no one" `redis-cli -h 127.0.0.1 -p $redis_port -a $redis_passwd SLAVEOF NO ONE` >> $LOGFILE
local_ip=""
netif=""
slave_ips=""
for ip in `echo "$redis_master_ip $redis_backup_ips" | cut -d ' ' -f 1-`
do
	netif=`ip a | grep "$ip/" | rev | cut -d ' ' -f 1 | rev`
	if [ "$netif" != "" ]
	then
		local_ip=$ip
    else
        slave_ips="$slave_ips,$ip"
	fi
done
iparr=(`echo $slave_ips | tr ',' ' '`)
for ip in ${iparr[@]}
do
    echo `date` "remote $ip slaveof $local_ip $redis_port" `redis-cli -h $ip -p $redis_port -a $redis_passwd SLAVEOF $local_ip $redis_port` >> $LOGFILE
done
sleep 2
for ip in ${iparr[@]}
do
	linkstatus=`redis-cli -h $ip -p $redis_port -a $redis_passwd info replication | grep 'master_link_status' | sed s/[[:space:]]//g`
	if [ "$linkstatus" = "master_link_status:down" ]
	then
		echo `date` "remote $ip slaveof $local_ip $redis_port $linkstatus fail" >> $LOGFILE
		echo `date` "remote $ip slaveof $local_ip $redis_port" `redis-cli -h $ip -p $redis_port -a $redis_passwd SLAVEOF $local_ip $redis_port` >> $LOGFILE
	fi
done
