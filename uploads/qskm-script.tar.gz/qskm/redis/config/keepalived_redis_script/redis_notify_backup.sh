#!/bin/bash
source ./redis-config.sh
LOGFILE=`dirname $redis_logfile`/keepalived-notify.log
echo `date` "notify backup" >> $LOGFILE
sleep 2
vipretry=2
vip_found=0
while [ $vipretry -gt 0 ]
do
    vipfound=`ip a | grep " $redis_vip/" | wc -l`
    if [ "$vipfound" = "1" ]
    then
        vip_found=1
        vipretry=$[ $vipretry - 1 ]
        sleep 1
        continue
    else
        vip_found=0
        break
    fi
done
if [ $vip_found -eq 1 ]
then
    echo `date` "vip found: $redis_vip" >> $LOGFILE
    exit 0
fi
local_ip=""
netif=""
else_ips=""
for ip in `echo "$redis_master_ip $redis_backup_ips" | cut -d ' ' -f 1-`
do
	netif=`ip a | grep "$ip/" | rev | cut -d ' ' -f 1 | rev`
	if [ "$netif" != "" ]
	then
		local_ip=$ip
    else
        else_ips="$else_ips,$ip"
	fi
done
iparr=(`echo $else_ips | tr ',' ' '`)
masterip=""
masterNum=0
function findMaster {
    for ip in ${iparr[@]}
    do
        ismaster=`redis-cli -h $ip -p $redis_port -a $redis_passwd info replication | grep 'role:master' | wc -l`
        if [ "$ismaster" = "1" ]
        then
            masterip=$ip
            masterNum=$[ $masterNum + 1 ]
            break
        fi
    done
}
retry=3
while [ $retry -gt 0 ]
do
    findMaster
    if [ "$masterip" == "" ]
    then
        echo `date` "master not found($retry)" >> $LOGFILE
        sleep 1
        retry=$[ $retry - 1 ]
        continue
    else
        break
    fi
done
if [ "$masterip" == "" ]
then
    echo `date` "master not found, slaveof exit" >> $LOGFILE
    exit 0
fi
if [ $masterNum -gt 1 ]
then
    echo `date` "masterNum=$masterNum masterip=$masterip, change to vip" >> $LOGFILE
    masterip=$redis_vip
fi
vipfound=`ip a | grep " $redis_vip/" | wc -l`
if [ "$vipfound" = "1" ]
then
    echo `date` "vip found: $redis_vip" >> $LOGFILE
    exit 0
fi
echo `date` "local $local_ip slaveof $masterip $redis_port" `redis-cli -h 127.0.0.1 -p $redis_port -a $redis_passwd SLAVEOF $masterip $redis_port` >> $LOGFILE
sleep 1
linkstatus=`redis-cli -h 127.0.0.1 -p $redis_port -a $redis_passwd info replication | grep 'master_link_status' | sed s/[[:space:]]//g`
if [ "$linkstatus" = "master_link_status:up" ]
then
    echo `date` "local $local_ip slaveof $ip $redis_port $linkstatus ok" >> $LOGFILE
else
    echo `date` "local $local_ip slaveof $ip $redis_port $linkstatus fail" >> $LOGFILE
    echo `date` "local $local_ip slaveof $masterip $redis_port" `redis-cli -h 127.0.0.1 -p $redis_port -a $redis_passwd SLAVEOF $masterip $redis_port` >> $LOGFILE
fi
