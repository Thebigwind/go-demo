#!/bin/bash
source ./redis-config.sh
LOGFILE=`dirname $redis_logfile`/keepalived-notify.log
echo `date` "notify fault" >> $LOGFILE
#todo 发邮件
