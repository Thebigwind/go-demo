#!/bin/bash 
#配置
nginx_ver=1.22.1
nginx_user=zdlz
nginx_group=zdlz
nginx_port=8080
nginx_upstream_port=9801
nginx_pidfile=/data/nginx/nginx.pid
nginx_access_log=/data/nginx/access.log
nginx_error_log=/data/nginx/error.log
nginx_cache_dir=/data/nginx/cache
nginx_master_ip=10.10.10.214
nginx_backup_ips="10.10.10.204 10.10.10.224"
nginx_vip=10.10.10.177
nginx_virtual_router_id=22
