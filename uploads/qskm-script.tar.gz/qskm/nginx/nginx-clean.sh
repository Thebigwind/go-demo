#!/bin/bash
systemctl stop keepalived
systemctl disable keepalived
yum erase keepalived -y
systemctl stop nginx
systemctl disable nginx
yum erase nginx -y
rm -drf /data/nginx
rm -f /etc/nginx/conf.d/default.conf
rm -drf /data/keepalived
echo "" > /etc/keepalived/keepalived_nginx.conf
rm -drf /etc/keepalived/keepalived_nginx_script
rm -drf /tmp/nginx
rm -drf /tmp/keepalived
