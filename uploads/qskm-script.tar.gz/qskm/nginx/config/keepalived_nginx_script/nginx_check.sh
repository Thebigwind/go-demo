#!/bin/bash 
source /etc/keepalived/keepalived_nginx_script/nginx-config.sh
LOGFILE=`dirname $nginx_access_log`/keepalived-check.log
nginxhad=`ps aux | grep nginx | grep -v script | grep -v 'grep' | wc -l`
if [ "$nginxhad" = "0" ]
then
    echo `date` "check fail: ps=$nginxhad" >> $LOGFILE 2>&1
    exit 1 
else
    echo `date` "check ok: ps=$nginxhad" >> $LOGFILE 2>&1
    exit 0   
fi
