#!/bin/bash
source ./nginx-config.sh
LOGFILE=`dirname $nginx_access_log`/keepalived-notify.log
echo `date` "notify master" >> $LOGFILE
