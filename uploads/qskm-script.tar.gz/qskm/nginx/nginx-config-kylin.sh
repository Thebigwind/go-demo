#!/bin/bash 
#配置
nginx_ver=1.22.1
nginx_user=zdlz
nginx_group=zdlz
nginx_port=8080
nginx_upstream_port=9801
nginx_pidfile=/data/nginx/nginx.pid
nginx_access_log=/data/nginx/access.log
nginx_error_log=/data/nginx/error.log
nginx_cache_dir=/data/nginx/cache
nginx_master_ip=10.10.10.164
nginx_backup_ips="10.10.10.154 10.10.10.242"
nginx_vip=10.10.10.166
nginx_virtual_router_id=12
