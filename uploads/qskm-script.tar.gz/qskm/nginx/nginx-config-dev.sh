#!/bin/bash 
#配置
nginx_ver=1.22.1
nginx_user=work
nginx_group=work
nginx_port=8080
nginx_upstream_port=9801
nginx_pidfile=/data/nginx/nginx.pid
nginx_access_log=/data/nginx/access.log
nginx_error_log=/data/nginx/error.log
nginx_cache_dir=/data/nginx/cache
nginx_master_ip=192.168.36.3
nginx_backup_ips="192.168.36.4 192.168.36.5"
nginx_vip=192.168.36.31
#nginx_master_ip=192.168.56.101
#nginx_backup_ips="192.168.56.102"
#nginx_vip=192.168.56.110
nginx_virtual_router_id=12
