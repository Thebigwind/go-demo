#!/bin/bash 
#配置
configshell=./nginx-config.sh
scriptenv=""
if [ "$1" == "--env" ] && [ "$2" != "" ]
then
	scriptenv=$2
	configshell=./nginx-config-$2.sh
	if [ ! -e $configshell ]
	then
		echo "config file $configshell not exist!"
		exit 1
	fi
fi
echo "use config file $configshell"
source $configshell
sbinhad=`echo $PATH | grep '/usr/sbin' | wc -l`
if [ "$sbinhad" = "0" ]
then
	PATH=$PATH:/usr/sbin
fi
#安装
exist=`nginx -v 2>&1 | grep $nginx_ver | wc -l`
if [ "$exist" = "0" ]
then
	tmpdir=/tmp/nginx
	mkdir -p $tmpdir
	nginx_rpm=nginx-${nginx_ver}-1.el7.ngx.x86_64.rpm
	if [ ! -s $tmpdir/$nginx_rpm ]
	then
		which wget &>/dev/null
		if [ $? -ne 0 ]
		then
			sudo yum install wget -y
		fi
		wget --no-check-certificate https://nginx.org/packages/centos/7/x86_64/RPMS/$nginx_rpm -O $tmpdir/$nginx_rpm
	fi
	is_kylin=`cat /etc/system-release | grep Tercel | wc -l`
	if [ "$is_kylin" == "1" ]
	then
		if [ ! -s $tmpdir/mailcap-2.1.48-3.el8.noarch.rpm ]
		then
			wget --no-check-certificate https://www.rpmfind.net/linux/centos/8-stream/BaseOS/x86_64/os/Packages/mailcap-2.1.48-3.el8.noarch.rpm -O $tmpdir/mailcap-2.1.48-3.el8.noarch.rpm
		fi
		sudo yum erase mailcap -y
		sudo rpm -i $tmpdir/mailcap-2.1.48-3.el8.noarch.rpm
	else
		pcre2had=`ldconfig -p | grep pcre2 | wc -l`
		if [ "$pcre2had" = "0" ]
		then
			sudo yum install pcre2-devel.x86_64 -y
		fi
	fi
	sudo rpm -i $tmpdir/$nginx_rpm
	if [ $? -ne 0 ]
	then
		echo "nginx安装失败"
		exit 1
	fi
fi
#替换配置
sudo chown $nginx_user.$nginx_group -R /etc/nginx
sudo chmod 775 /etc/nginx
sudo -u $nginx_user cp -f ./config/nginx.conf /etc/nginx/nginx.conf
sudo mkdir -p `dirname $nginx_pidfile` `dirname $nginx_access_log` `dirname $nginx_error_log` $nginx_cache_dir
sudo chown $nginx_user.$nginx_group -R `dirname $nginx_pidfile` `dirname $nginx_access_log` `dirname $nginx_error_log` $nginx_cache_dir
sudo sed -i "s/user root;/user $nginx_user;/g" /etc/nginx/nginx.conf
sudo sed -i "s#access_log.*;#access_log $nginx_access_log main;#g" /etc/nginx/nginx.conf
sudo sed -i "s#error_log.*;#error_log $nginx_error_log warn;#g" /etc/nginx/nginx.conf
sudo sed -i "s#/var/cache/nginx/cache#$nginx_cache_dir#g" /etc/nginx/nginx.conf
sudo sed -i "s#/var/run/nginx.pid#$nginx_pidfile#g" /etc/nginx/nginx.conf
upstream_servers=""
for ip in `echo "$nginx_master_ip $nginx_backup_ips" | cut -d ' ' -f 1-`
do
	upstream_servers="${upstream_servers}server ${ip}:${nginx_upstream_port};\n"
done
sudo sed -i "s/{upstream}/$upstream_servers/g" /etc/nginx/nginx.conf
sudo -u $nginx_user cp -f ./config/conf.d-default.conf /etc/nginx/conf.d/default.conf
sudo sed -i "s/listen.*;/listen $nginx_port;/g" /etc/nginx/conf.d/default.conf
sudo sed -i "s#access_log.*;#access_log $nginx_access_log main;#g" /etc/nginx/conf.d/default.conf
sudo sed -i "s#error_log.*;#error_log $nginx_error_log warn;#g" /etc/nginx/conf.d/default.conf
#firewall
portyes=`sudo firewall-cmd --query-port=$nginx_port/tcp --permanent`
if [ "$portyes" == "no" ]
then
	sudo firewall-cmd --add-port=$nginx_port/tcp --permanent
	sudo firewall-cmd --reload
fi
upstreamportyes=`sudo firewall-cmd --query-port=$nginx_upstream_port/tcp --permanent`
if [ "$upstreamportyes" == "no" ]
then
	sudo firewall-cmd --add-port=$nginx_upstream_port/tcp --permanent
	sudo firewall-cmd --reload
fi
#selinux
seenforce=`getenforce | grep Enforcing | wc -l`
if [ "$seenforce" == "1" ]
then
	which semanage &>/dev/null
	if [ $? -ne 0 ]
	then
		sudo yum install policycoreutils-python-2.5-34.el7.x86_64 -y
	fi
	seperm=`sudo semanage permissive -l | grep httpd_t | wc -l`
	if [ "$seperm" == "0" ]
	then
		sudo semanage permissive -a httpd_t
	fi
fi
#systemd
sudo cp -f ./config/nginx.service /usr/lib/systemd/system/nginx.service
#sudo sed -i "s/User=.*/User=$nginx_user/g" /usr/lib/systemd/system/nginx.service
#sudo sed -i "s/Group=.*/Group=$nginx_group/g" /usr/lib/systemd/system/nginx.service
sudo sed -i "s#/var/run/nginx.pid#$nginx_pidfile#g" /usr/lib/systemd/system/nginx.service
sudo systemctl daemon-reload 
sudo systemctl enable nginx
#运行
sudo systemctl stop nginx
sudo systemctl start nginx
#配置keepalived
if [ ! -e /etc/systemd/system/multi-user.target.wants/keepalived.service ]
then
	oldpwd=`pwd`
	cd ../keepalived/
	if [ "$scriptenv" = "" ]
	then
		sh keepalived-install.sh
	else
		sh keepalived-install.sh --env $scriptenv
	fi
	if [ $? -ne 0 ]
	then
		exit 1
	fi
	cd $oldpwd
fi
sudo -u $nginx_user cp -f ./config/keepalived_nginx.conf /etc/keepalived/keepalived_nginx.conf
sudo chmod 644 /etc/keepalived/keepalived_nginx.conf
sudo mkdir -p /etc/keepalived/keepalived_nginx_script
sudo chown $nginx_user.$nginx_group -R /etc/keepalived/keepalived_nginx_script
sudo -u $nginx_user cp -f $configshell /etc/keepalived/keepalived_nginx_script/nginx-config.sh
sudo -u $nginx_user cp -f ./config/keepalived_nginx_script/* /etc/keepalived/keepalived_nginx_script/
for f in `ls /etc/keepalived/keepalived_nginx_script/*.sh`
do
	sudo sed -i "s#source ./nginx-config.sh#source /etc/keepalived/keepalived_nginx_script/nginx-config.sh#g" $f
	sudo -u $nginx_user chmod +x $f
done
local_ip=""
netif=""
for ip in `echo "$nginx_master_ip $nginx_backup_ips" | cut -d ' ' -f 1-`
do
	netif=`ip a | grep "$ip/" | rev | cut -d ' ' -f 1 | rev`
	if [ "$netif" != "" ]
	then
		local_ip=$ip
		break
	fi
done
if [ "$netif" = "" ]
then
	echo "$nginx_master_ip $nginx_backup_ips not exist!"
	exit 1
fi
if [ "$local_ip" = "$nginx_master_ip" ]
then
	state="MASTER"
	priority=100
else
	state="BACKUP"
	priority=90
fi
sudo sed -i "s/state .*/state $state/g" /etc/keepalived/keepalived_nginx.conf
sudo sed -i "s/interface.*/interface $netif/g" /etc/keepalived/keepalived_nginx.conf
sudo sed -i "s/priority.*/priority $priority/g" /etc/keepalived/keepalived_nginx.conf
sudo sed -i "s/virtual_router_id 1/virtual_router_id $nginx_virtual_router_id/g" /etc/keepalived/keepalived_nginx.conf
sudo sed -i "s/192.168.56.233/$nginx_vip/g" /etc/keepalived/keepalived_nginx.conf
keeppid=`pgrep keepalived | sort | head -1`
if [ "$keeppid" = "" ]
then
	sudo systemctl start keepalived
else
	sudo kill -1 $keeppid
fi
#ok?
nginxpid=`pgrep nginx | sort | head -1`
if [ "$nginxpid" = "" ]
then
	echo "nginx启动失败"
else
	echo "nginx已启动"
fi
